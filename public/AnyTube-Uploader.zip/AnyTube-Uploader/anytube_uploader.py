#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AnyTube Uploader — загружает видео и комментарии на GitHub для сайта AnyTube.

  Видео:       <ваш_ник>/anytubevideo_<имя>          с файлом <имя>.mp4
  Комментарий: <ваш_ник>/anytubecomment_<автор>_<файл>_Comment.<N>

Сам скачивает всё нужное (Windows): портативный Git, Git LFS, FFmpeg.
Только стандартная библиотека Python, pip не нужен.
Запуск: AnyTube.cmd (или перетащите видео на AnyTube.cmd).
"""
import base64
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(APP_DIR, "tools")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
IS_WIN = os.name == "nt"

VIDEO_PREFIX = "anytubevideo_"
COMMENT_PREFIX = "anytubecomment_"
MB = 1024 ** 2
PLAIN_LIMIT = 95 * MB        # GitHub не принимает обычные файлы больше 100 МБ
LFS_LIMIT = 1950 * MB        # Git LFS на бесплатном GitHub — до 2 ГБ на файл
WEB_EXT = {".mp4", ".webm"}  # играют во всех браузерах; остальное конвертируем в mp4
VIDEO_TYPES = "*.mp4 *.webm *.mov *.m4v *.mkv *.avi *.wmv *.flv *.3gp *.ts *.mpg *.mpeg *.ogv"

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
os.makedirs(TOOLS, exist_ok=True)
os.environ["GIT_TERMINAL_PROMPT"] = "0"
os.environ["GCM_INTERACTIVE"] = "never"


# ─────────────────────────── мелочи ───────────────────────────
class Stop(Exception):
    """Понятная пользователю ошибка: показать и вернуться в меню."""


def say(*a):
    print(*a, flush=True)


def ask(prompt, default=""):
    hint = f" [{default}]" if default else ""
    try:
        s = input(f"{prompt}{hint}: ").strip()
    except EOFError:
        s = ""
    return s or default


def human(n):
    return f"{n / MB:.1f} МБ" if n < 1024 * MB else f"{n / 1024 / MB:.2f} ГБ"


def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config():
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(CFG, f, ensure_ascii=False, indent=2)


CFG = load_config()

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
    "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya", "і": "i", "ї": "yi", "є": "ye", "ґ": "g",
}


def slug(text):
    """Имя для GitHub: только латиница, цифры, '-' и '_'."""
    s = "".join(TRANSLIT.get(c, c) for c in text.lower())
    s = re.sub(r"[^a-z0-9-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_-")
    return s or "video"


def safe_file_part(name):
    """Так же, как сайт, приводим имя файла к символам, допустимым в имени репозитория."""
    return re.sub(r"[^A-Za-z0-9._-]", "-", name)


# ─────────────────────────── сеть / GitHub API ───────────────────────────
def http(method, url, data=None, token=None):
    headers = {"User-Agent": "anytube-uploader", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None), {k.lower(): v for k, v in r.headers.items()}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw)
        except Exception:
            j = {"message": raw.decode(errors="replace")[:300]}
        return e.code, j, {k.lower(): v for k, v in e.headers.items()}
    except urllib.error.URLError as e:
        raise Stop(f"Нет связи с {urllib.parse.urlparse(url).netloc}: {e.reason}")


def gh(method, path, data=None):
    return http(method, "https://api.github.com" + path, data, token=CFG.get("token"))


def gh_error(st, j):
    msg = (j or {}).get("message", "")
    errs = "; ".join(str(e.get("message") or e) for e in (j or {}).get("errors", []) if e)
    return f"{st} {msg}{' — ' + errs if errs else ''}"


def download(url, dest):
    say(f"  Скачиваю: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "anytube-uploader"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest + ".part", "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r  {done * 100 // total:3d}%  {done // MB}/{total // MB} МБ", end="", flush=True)
    print()
    os.replace(dest + ".part", dest)


def latest_asset(repo, pattern):
    st, j, _ = http("GET", f"https://api.github.com/repos/{repo}/releases/latest")
    if st != 200:
        raise Stop(f"Не удалось узнать последнюю версию {repo}: {gh_error(st, j)}")
    for a in j.get("assets", []):
        if re.search(pattern, a["name"]):
            return a["browser_download_url"]
    raise Stop(f"В релизе {repo} нет подходящего файла")


# ─────────────────────────── инструменты ───────────────────────────
def add_path(*dirs):
    have = os.environ.get("PATH", "").split(os.pathsep)
    new = [d for d in dirs if os.path.isdir(d) and d not in have]
    if new:
        os.environ["PATH"] = os.pathsep.join(new + have)


def works(cmd):
    try:
        return subprocess.run(cmd, capture_output=True).returncode == 0
    except OSError:
        return False


def run(cmd, cwd=None, quiet=False):
    r = subprocess.run(cmd, cwd=cwd, capture_output=quiet, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        tail = ((r.stderr or "") + (r.stdout or ""))[-800:] if quiet else ""
        raise Stop(f"Команда завершилась с ошибкой ({r.returncode}): {' '.join(cmd[:3])} …\n{tail}")
    return r


def extract_from_zip(zip_path, wanted, dest_dir):
    """Достаёт из архива файлы с именами из wanted (где бы они ни лежали)."""
    os.makedirs(dest_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for m in zf.namelist():
            name = m.rsplit("/", 1)[-1]
            if name in wanted:
                with zf.open(m) as s, open(os.path.join(dest_dir, name), "wb") as d:
                    shutil.copyfileobj(s, d)


def ensure_git():
    pg = os.path.join(TOOLS, "PortableGit")
    lfs_dir = os.path.join(TOOLS, "git-lfs")
    add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"), lfs_dir)
    if not works(["git", "--version"]):
        if not IS_WIN:
            raise Stop("Git не найден. Установите: sudo apt install git git-lfs  (или brew install git git-lfs)")
        say("Git не найден — скачиваю портативный Git for Windows (один раз, ~60 МБ)…")
        url = latest_asset("git-for-windows/git", r"^PortableGit-[\d.]+-64-bit\.7z\.exe$")
        exe = os.path.join(TOOLS, "PortableGit.7z.exe")
        download(url, exe)
        say("  Распаковываю Git…")
        subprocess.run([exe, "-o" + pg, "-y"], check=True)
        os.remove(exe)
        add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"))
    if not works(["git", "lfs", "version"]):
        if not IS_WIN:
            raise Stop("Git LFS не найден. Установите: sudo apt install git-lfs  (или brew install git-lfs)")
        say("Git LFS не найден — скачиваю (один раз, ~10 МБ)…")
        url = latest_asset("git-lfs/git-lfs", r"^git-lfs-windows-amd64-v[\d.]+\.zip$")
        z = os.path.join(TOOLS, "git-lfs.zip")
        download(url, z)
        extract_from_zip(z, {"git-lfs.exe"}, lfs_dir)
        os.remove(z)
        add_path(lfs_dir)
        if not works(["git", "lfs", "version"]):
            raise Stop("Git LFS так и не запустился")


def ensure_ffmpeg(required=True):
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if works(["ffmpeg", "-version"]) and works(["ffprobe", "-version"]):
        return True
    if not required:
        return False
    if not IS_WIN:
        raise Stop("FFmpeg не найден. Установите: sudo apt install ffmpeg  (или brew install ffmpeg)")
    say("FFmpeg не найден — скачиваю (один раз, ~150 МБ)…")
    url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
    z = os.path.join(TOOLS, "ffmpeg.zip")
    download(url, z)
    say("  Распаковываю FFmpeg…")
    extract_from_zip(z, {"ffmpeg.exe", "ffprobe.exe"}, os.path.join(TOOLS, "ffmpeg", "bin"))
    os.remove(z)
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if not works(["ffmpeg", "-version"]):
        raise Stop("FFmpeg так и не запустился")
    return True


# ─────────────────────────── токен ───────────────────────────
TOKEN_HELP = """
Нужен токен GitHub, чтобы создавать репозитории от вашего имени.
  1. Откройте https://github.com/settings/tokens/new  (Tokens (classic))
  2. Note: AnyTube Uploader, Expiration: на ваш выбор
  3. Отметьте галочку  public_repo  (больше ничего не нужно)
  4. Generate token → скопируйте токен (ghp_…)
Токен хранится только в config.json рядом с программой. Никому не передавайте этот файл.
Это НЕ тот токен, что на Render: тому права не нужны, этому нужен public_repo.
"""


def ensure_token(force=False):
    while True:
        if CFG.get("token") and not force:
            st, j, h = gh("GET", "/user")
            if st == 200:
                CFG["login"], CFG["user_id"] = j["login"], j["id"]
                save_config()
                scopes = h.get("x-oauth-scopes")
                if scopes is not None and not {"public_repo", "repo"} & {s.strip() for s in scopes.split(",")}:
                    say("⚠ У токена нет права public_repo — создать репозиторий не получится. Создайте новый токен.")
                    force = True
                    continue
                return
            say(f"Сохранённый токен не принят GitHub ({st}).")
        say(TOKEN_HELP)
        tok = ask("Вставьте токен").strip().strip('"')
        tok = re.sub(r"^Bearer\s+", "", tok, flags=re.I)
        if not tok:
            raise Stop("Токен не введён")
        CFG["token"] = tok
        force = False


def ensure_site():
    if "site" not in CFG:
        s = ask("Адрес вашего сайта AnyTube (например https://anytube.onrender.com), Enter — пропустить")
        CFG["site"] = s.rstrip("/")
        save_config()
    return CFG.get("site", "")


# ─────────────────────────── видео: обработка ───────────────────────────
def probe_duration(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], quiet=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        raise Stop("FFmpeg не смог определить длительность видео")


def transcode(src, dst, target_bytes=None):
    """target_bytes=None — максимум качества (CRF 20); иначе двухпроходное сжатие под размер."""
    base = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", src]
    even = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    out = ["-pix_fmt", "yuv420p", "-movflags", "+faststart", dst]
    if target_bytes is None:
        say("  Конвертирую в MP4 (H.264, высокое качество)…")
        run(base + ["-vf", even, "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                    "-c:a", "aac", "-b:a", "160k"] + out)
        return
    dur = probe_duration(src)
    factor = 0.95
    for _ in range(3):
        total_kbps = target_bytes * 8 / 1000 / dur * factor
        a_kbps = 128 if total_kbps > 900 else 64
        v_kbps = int(total_kbps - a_kbps)
        if v_kbps < 120:
            raise Stop(f"Видео слишком длинное ({dur / 60:.0f} мин), чтобы уместить его в {human(target_bytes)} "
                       f"с приемлемым качеством. Выберите вариант с Git LFS или обрежьте видео.")
        if v_kbps < 700:
            vf = "scale=-2:'2*trunc(min(480,ih)/2)'"
        elif v_kbps < 1800:
            vf = "scale=-2:'2*trunc(min(720,ih)/2)'"
        elif v_kbps < 4500:
            vf = "scale=-2:'2*trunc(min(1080,ih)/2)'"
        else:
            vf = even
        say(f"  Сжимаю до ~{human(target_bytes)}: видео {v_kbps} кбит/с, звук {a_kbps} кбит/с (2 прохода)…")
        passlog = os.path.join(tempfile.gettempdir(), "anytube_2pass")
        enc = ["-vf", vf, "-c:v", "libx264", "-preset", "medium", "-b:v", f"{v_kbps}k",
               "-maxrate", f"{int(v_kbps * 1.6)}k", "-bufsize", f"{v_kbps * 2}k", "-passlogfile", passlog]
        run(base + enc + ["-pass", "1", "-an", "-pix_fmt", "yuv420p", "-f", "mp4", os.devnull])
        run(base + enc + ["-pass", "2", "-c:a", "aac", "-b:a", f"{a_kbps}k"] + out)
        if os.path.getsize(dst) <= target_bytes:
            return
        factor *= 0.9
        say(f"  Получилось {human(os.path.getsize(dst))} — чуть больше нужного, пересжимаю…")
    raise Stop("Не удалось уложиться в размер")


def place_file(src, dst):
    """Кладёт исходник в папку репозитория без лишнего копирования, если можно."""
    try:
        os.link(src, dst)
    except OSError:
        say("  Копирую файл…")
        shutil.copy2(src, dst)


def faststart(src, dst):
    """MP4 с индексом в начале — начинает играть сразу. Быстро, без перекодирования."""
    say("  Оптимизирую MP4 для просмотра онлайн (faststart)…")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-map", "0",
                        "-c", "copy", "-movflags", "+faststart", dst], capture_output=True)
    if r.returncode != 0 or not os.path.exists(dst):
        place_file(src, dst)


def rmtree(path):
    def onerror(func, p, _):
        os.chmod(p, stat.S_IWRITE)
        func(p)
    if os.path.isdir(path):
        shutil.rmtree(path, onerror=onerror)


def pick_file():
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(title="Выберите видео для AnyTube",
                                          filetypes=[("Видео", VIDEO_TYPES), ("Все файлы", "*.*")])
        root.destroy()
        return path
    except Exception:
        return ask("Путь к видеофайлу (можно перетащить файл в это окно)")


def repo_exists(name):
    st, _, _ = gh("GET", f"/repos/{CFG['login']}/{name}")
    return st == 200


def free_repo_name(name):
    if not repo_exists(name):
        return name
    n = 2
    while repo_exists(f"{name}_{n}"):
        n += 1
    return f"{name}_{n}"


# ─────────────────────────── загрузка видео ───────────────────────────
def upload_video(path=None):
    ensure_token()
    site = ensure_site()
    path = (path or pick_file() or "").strip().strip('"')
    if not path or not os.path.isfile(path):
        raise Stop("Файл не выбран или не найден")
    stem, ext = os.path.splitext(os.path.basename(path))
    ext = ext.lower()
    size = os.path.getsize(path)
    say(f"\nФайл: {path}  ({human(size)})")

    title = ask("Название видео (заголовок на сайте)", stem)
    base = slug(ask("Короткое имя для ссылки (латиница)", slug(stem)))[:80]
    repo = free_repo_name(VIDEO_PREFIX + base)
    out_name = base + (ext if ext in WEB_EXT else ".mp4")

    needs_convert = ext not in WEB_EXT
    target = None
    if needs_convert:
        say(f"Формат {ext} плохо играет в браузерах — сконвертирую в MP4.")
    if size > PLAIN_LIMIT or needs_convert:
        too_big = size > LFS_LIMIT
        say("\nКак загрузить?")
        say(f"  1 — Максимальное качество через Git LFS"
            f"{' (видео больше 2 ГБ — сначала сожму до ~1.9 ГБ)' if too_big else ''}  [рекомендуется]")
        say("  2 — Сжать до 95 МБ и загрузить без LFS (не тратит квоту LFS, качество ниже)")
        choice = ask("Ваш выбор", "1")
        if choice == "2":
            target = PLAIN_LIMIT
        elif too_big:
            target = int(LFS_LIMIT * 0.97)

    work = os.path.join(TOOLS, "work", repo)
    rmtree(work)
    os.makedirs(work)
    dst = os.path.join(work, out_name)
    try:
        if needs_convert or target:
            ensure_ffmpeg()
            transcode(path, dst, target)
            if target is None and os.path.getsize(dst) > LFS_LIMIT:
                say(f"После конвертации {human(os.path.getsize(dst))} — больше лимита LFS, сжимаю…")
                os.remove(dst)
                transcode(path, dst, int(LFS_LIMIT * 0.97))
        elif ext == ".mp4" and ensure_ffmpeg(required=size > PLAIN_LIMIT):
            faststart(path, dst)
        else:
            place_file(path, dst)

        final = os.path.getsize(dst)
        use_lfs = final > PLAIN_LIMIT
        say(f"\nГотово к загрузке: {out_name} ({human(final)}){' через Git LFS' if use_lfs else ''}")
        ensure_git()

        login = CFG["login"]
        watch = f"{site}/watch?v={urllib.parse.quote(f'{login}/{repo}/{out_name}', safe='')}" if site else ""
        say(f"Создаю репозиторий {login}/{repo}…")
        st, j, _ = gh("POST", "/user/repos", {
            "name": repo, "description": title[:300], "homepage": watch, "private": False,
            "has_issues": False, "has_wiki": False, "has_projects": False,
        })
        if st != 201:
            raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
        gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubevideo"]})

        with open(os.path.join(work, "README.md"), "w", encoding="utf-8") as f:
            f.write(f"# {title}\n\nВидео для AnyTube: `{out_name}`\n" + (f"\nСмотреть: {watch}\n" if watch else ""))

        auth = base64.b64encode(f"{login}:{CFG['token']}".encode()).decode()
        git = lambda *a: run(["git", *a], cwd=work)
        git("init", "-q")
        git("checkout", "-q", "-b", "main")
        git("config", "user.name", login)
        git("config", "user.email", f"{CFG['user_id']}+{login}@users.noreply.github.com")
        git("config", "credential.helper", "")
        git("config", "http.https://github.com/.extraheader", f"AUTHORIZATION: basic {auth}")
        git("config", "lfs.locksverify", "false")
        if use_lfs:
            git("lfs", "install", "--local")
            git("lfs", "track", out_name)
        git("add", "-A")
        git("commit", "-q", "-m", f"AnyTube: {title}")
        git("remote", "add", "origin", f"https://github.com/{login}/{repo}.git")
        say("Загружаю на GitHub… (большое видео может грузиться долго)")
        git("push", "-u", "origin", "main")
    finally:
        rmtree(work)  # удаляет и копию видео, и токен из настроек временного репозитория

    say("\n✅ Видео загружено!")
    say(f"   Репозиторий: https://github.com/{login}/{repo}")
    if watch:
        say(f"   На AnyTube:  {watch}")
    say("   На сайте появится в течение ~10 минут (поиск GitHub иногда дольше).")


# ─────────────────────────── комментарии ───────────────────────────
def parse_video_ref(ref):
    """Принимает ссылку AnyTube (…/watch?v=…), id 'автор/репо/файл.mp4' или 'автор/файл.mp4'."""
    ref = ref.strip().strip('"')
    if "v=" in ref:
        ref = urllib.parse.parse_qs(urllib.parse.urlparse(ref).query).get("v", [""])[0]
    ref = urllib.parse.unquote(ref).strip("/")
    parts = [p for p in ref.split("/") if p]
    if len(parts) < 2:
        raise Stop("Не понял, к какому видео комментарий. Вставьте ссылку со страницы видео на AnyTube.")
    return parts[0], parts[-1]


def comment_stem(author, file_name):
    head = f"{COMMENT_PREFIX}{author}_"
    tail = "_Comment."
    file_part = safe_file_part(file_name)[: 100 - len(head) - len(tail) - 4]
    return f"{head}{file_part}{tail}"


def next_comment_number(stem):
    nums = [0]
    page = 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список ваших репозиториев: {gh_error(st, j)}")
        for r in j:
            if r["name"].lower().startswith(stem.lower()):
                tail = r["name"][len(stem):]
                if tail.isdigit():
                    nums.append(int(tail))
        if len(j) < 100:
            return max(nums) + 1
        page += 1


def post_comment():
    ensure_token()
    author, file_name = parse_video_ref(ask("Ссылка на видео AnyTube (или автор/репозиторий/файл.mp4)"))
    say(f"Комментарий к видео {file_name} автора {author}.")
    say("Напишите комментарий. Чтобы закончить — пустая строка.")
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if not line.strip():
            break
        lines.append(line)
    text = "\n".join(lines).strip()
    if not text:
        raise Stop("Пустой комментарий не отправлен")

    login = CFG["login"]
    stem = comment_stem(author, file_name)
    num = next_comment_number(stem)
    repo = f"{stem}{num}"
    say(f"Создаю {login}/{repo}…")
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": " ".join(text.split())[:300], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
    gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubecomment"]})
    body = f"---\nvideo_author: {author}\nvideo_file: {file_name}\n---\n\n{text}\n"
    st, j, _ = gh("PUT", f"/repos/{login}/{repo}/contents/comment.md", {
        "message": "AnyTube comment", "content": base64.b64encode(body.encode()).decode(),
    })
    if st not in (200, 201):
        say(f"⚠ Полный текст не сохранился ({gh_error(st, j)}), но короткая версия есть в описании.")
    say(f"\n✅ Комментарий №{num} опубликован: https://github.com/{login}/{repo}")
    say("   На сайте появится в течение ~10 минут. Удалить — удалите этот репозиторий.")


# ─────────────────────────── меню ───────────────────────────
def main():
    say("═══════════ AnyTube Uploader ═══════════")
    args = [a for a in sys.argv[1:] if a.strip()]
    if args:  # видео перетащили на AnyTube.cmd
        for p in args:
            try:
                upload_video(p)
            except Stop as e:
                say(f"\n❌ {e}")
        return
    while True:
        say(f"\n{'Аккаунт: ' + CFG['login'] if CFG.get('login') else 'Аккаунт: не подключён'}")
        say("  1 — Загрузить видео")
        say("  2 — Написать комментарий к видео")
        say("  3 — Сменить токен GitHub")
        say("  4 — Сменить адрес сайта")
        say("  0 — Выход")
        c = ask("Выбор", "1")
        try:
            if c == "1":
                upload_video()
            elif c == "2":
                post_comment()
            elif c == "3":
                ensure_token(force=True)
                say(f"Подключён аккаунт {CFG['login']}")
            elif c == "4":
                CFG.pop("site", None)
                ensure_site()
            elif c == "0":
                return
        except Stop as e:
            say(f"\n❌ {e}")
        except KeyboardInterrupt:
            say("\nОтменено.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
