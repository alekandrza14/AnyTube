#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AnyTube Uploader — загружает видео и комментарии на GitHub для сайта AnyTube.

  Видео:       <ваш_ник>/anytubevideo_<имя>          с файлом <имя>.mp4
  Комментарий: <ваш_ник>/anytubecomment_<автор>_<файл>_Comment.<N>

Сам скачивает всё нужное (Windows): портативный Git, Git LFS, FFmpeg.
Только стандартная библиотека Python, pip не нужен.
Запуск: AnyTube.cmd (или перетащите видео на AnyTube.cmd).
"""
import base64
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(APP_DIR, "tools")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
IS_WIN = os.name == "nt"

VIDEO_PREFIX = "anytubevideo_"
COMMENT_PREFIX = "anytubecomment_"
MB = 1024 ** 2
PLAIN_LIMIT = 95 * MB        # GitHub не принимает обычные файлы больше 100 МБ
LFS_LIMIT = 1950 * MB        # Git LFS на бесплатном GitHub — до 2 ГБ на файл
WEB_EXT = {".mp4", ".webm"}  # играют во всех браузерах; остальное конвертируем в mp4
VIDEO_TYPES = "*.mp4 *.webm *.mov *.m4v *.mkv *.avi *.wmv *.flv *.3gp *.ts *.mpg *.mpeg *.ogv"

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
os.makedirs(TOOLS, exist_ok=True)
os.environ["GIT_TERMINAL_PROMPT"] = "0"
os.environ["GCM_INTERACTIVE"] = "never"


# ─────────────────────────── мелочи ───────────────────────────
class Stop(Exception):
    """Понятная пользователю ошибка: показать и вернуться в меню."""


def say(*a):
    print(*a, flush=True)


def ask(prompt, default=""):
    hint = f" [{default}]" if default else ""
    try:
        s = input(f"{prompt}{hint}: ").strip()
    except EOFError:
        s = ""
    return s or default


def human(n):
    return f"{n / MB:.1f} МБ" if n < 1024 * MB else f"{n / 1024 / MB:.2f} ГБ"


def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config():
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(CFG, f, ensure_ascii=False, indent=2)


CFG = load_config()

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
    "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya", "і": "i", "ї": "yi", "є": "ye", "ґ": "g",
}


def slug(text):
    """Имя для GitHub: только латиница, цифры, '-' и '_'."""
    s = "".join(TRANSLIT.get(c, c) for c in text.lower())
    s = re.sub(r"[^a-z0-9-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_-")
    return s or "video"


def safe_file_part(name):
    """Так же, как сайт, приводим имя файла к символам, допустимым в имени репозитория."""
    return re.sub(r"[^A-Za-z0-9._-]", "-", name)


# ─────────────────────────── сеть / GitHub API ───────────────────────────
def http(method, url, data=None, token=None):
    headers = {"User-Agent": "anytube-uploader", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None), {k.lower(): v for k, v in r.headers.items()}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw)
        except Exception:
            j = {"message": raw.decode(errors="replace")[:300]}
        return e.code, j, {k.lower(): v for k, v in e.headers.items()}
    except urllib.error.URLError as e:
        raise Stop(f"Нет связи с {urllib.parse.urlparse(url).netloc}: {e.reason}")


def gh(method, path, data=None):
    return http(method, "https://api.github.com" + path, data, token=CFG.get("token"))


def gh_error(st, j):
    """Понятный текст ошибки GitHub. GitHub присылает errors то объектами, то просто строками."""
    if not isinstance(j, dict):
        j = {"message": str(j or "")}
    msg = str(j.get("message") or "")
    parts = []
    for e in j.get("errors") or []:
        if isinstance(e, dict):
            parts.append(str(e.get("message") or e.get("code") or e))
        elif e:
            parts.append(str(e))
    errs = "; ".join(parts)
    return f"{st} {msg}{' — ' + errs if errs else ''}"


def download(url, dest):
    say(f"  Скачиваю: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "anytube-uploader"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest + ".part", "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r  {done * 100 // total:3d}%  {done // MB}/{total // MB} МБ", end="", flush=True)
    print()
    os.replace(dest + ".part", dest)


def latest_asset(repo, pattern):
    st, j, _ = http("GET", f"https://api.github.com/repos/{repo}/releases/latest")
    if st != 200:
        raise Stop(f"Не удалось узнать последнюю версию {repo}: {gh_error(st, j)}")
    for a in j.get("assets", []):
        if re.search(pattern, a["name"]):
            return a["browser_download_url"]
    raise Stop(f"В релизе {repo} нет подходящего файла")


# ─────────────────────────── инструменты ───────────────────────────
def add_path(*dirs):
    have = os.environ.get("PATH", "").split(os.pathsep)
    new = [d for d in dirs if os.path.isdir(d) and d not in have]
    if new:
        os.environ["PATH"] = os.pathsep.join(new + have)


def works(cmd):
    try:
        return subprocess.run(cmd, capture_output=True).returncode == 0
    except OSError:
        return False


# Аварийные коды Windows: 0xC0000005 (нарушение доступа), 0xC0000142, 0xC0000409 — процесс упал сам,
# такую команду имеет смысл просто повторить.
CRASH_CODES = {3221225477, -1073741819, 3221225794, -1073741502, 3221226505, -1073740791}
CAPTURE_ALL = False  # окно включает: вывод команд собирается и показывается в журнале при ошибке


def run(cmd, cwd=None, quiet=False, retries=4, ok_if=None):
    cap = quiet or CAPTURE_ALL
    for attempt in range(retries):
        r = subprocess.run(cmd, cwd=cwd, capture_output=cap, text=True, encoding="utf-8", errors="replace")
        if r.returncode == 0 or (ok_if and ok_if(r)):
            return r
        if r.returncode in CRASH_CODES and attempt < retries - 1:
            say(f"  ⚠ {os.path.basename(cmd[0])} аварийно завершился (0x{r.returncode & 0xFFFFFFFF:08X}), повторяю…")
            time.sleep(1 + attempt)
            continue
        break
    tail = ((r.stderr or "") + (r.stdout or ""))[-800:] if cap else ""
    hint = ""
    if r.returncode in CRASH_CODES:
        hint = ("\nGit/FFmpeg падает на этом компьютере. Попробуйте: удалить папку tools рядом с программой "
                "(она скачается заново) или проверить антивирус.")
    raise Stop(f"Команда завершилась с ошибкой ({r.returncode}): {' '.join(cmd[:3])} …\n{tail}{hint}")


def extract_from_zip(zip_path, wanted, dest_dir):
    """Достаёт из архива файлы с именами из wanted (где бы они ни лежали)."""
    os.makedirs(dest_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for m in zf.namelist():
            name = m.rsplit("/", 1)[-1]
            if name in wanted:
                with zf.open(m) as s, open(os.path.join(dest_dir, name), "wb") as d:
                    shutil.copyfileobj(s, d)


def ensure_git():
    pg = os.path.join(TOOLS, "PortableGit")
    lfs_dir = os.path.join(TOOLS, "git-lfs")
    add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"), lfs_dir)
    if not works(["git", "--version"]):
        if not IS_WIN:
            raise Stop("Git не найден. Установите: sudo apt install git git-lfs  (или brew install git git-lfs)")
        say("Git не найден — скачиваю портативный Git for Windows (один раз, ~60 МБ)…")
        url = latest_asset("git-for-windows/git", r"^PortableGit-[\d.]+-64-bit\.7z\.exe$")
        exe = os.path.join(TOOLS, "PortableGit.7z.exe")
        download(url, exe)
        say("  Распаковываю Git…")
        subprocess.run([exe, "-o" + pg, "-y"], check=True)
        os.remove(exe)
        add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"))
    if not works(["git", "lfs", "version"]):
        if not IS_WIN:
            raise Stop("Git LFS не найден. Установите: sudo apt install git-lfs  (или brew install git-lfs)")
        say("Git LFS не найден — скачиваю (один раз, ~10 МБ)…")
        url = latest_asset("git-lfs/git-lfs", r"^git-lfs-windows-amd64-v[\d.]+\.zip$")
        z = os.path.join(TOOLS, "git-lfs.zip")
        download(url, z)
        extract_from_zip(z, {"git-lfs.exe"}, lfs_dir)
        os.remove(z)
        add_path(lfs_dir)
        if not works(["git", "lfs", "version"]):
            raise Stop("Git LFS так и не запустился")


def ensure_ffmpeg(required=True):
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if works(["ffmpeg", "-version"]) and works(["ffprobe", "-version"]):
        return True
    if not required:
        return False
    if not IS_WIN:
        raise Stop("FFmpeg не найден. Установите: sudo apt install ffmpeg  (или brew install ffmpeg)")
    say("FFmpeg не найден — скачиваю (один раз, ~150 МБ)…")
    url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
    z = os.path.join(TOOLS, "ffmpeg.zip")
    download(url, z)
    say("  Распаковываю FFmpeg…")
    extract_from_zip(z, {"ffmpeg.exe", "ffprobe.exe"}, os.path.join(TOOLS, "ffmpeg", "bin"))
    os.remove(z)
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if not works(["ffmpeg", "-version"]):
        raise Stop("FFmpeg так и не запустился")
    return True


# ─────────────────────────── токен ───────────────────────────
TOKEN_HELP = """
Нужен токен GitHub, чтобы создавать репозитории от вашего имени.
  1. Откройте https://github.com/settings/tokens/new  (Tokens (classic))
  2. Note: AnyTube Uploader, Expiration: на ваш выбор
  3. Отметьте галочку  public_repo  — для бесплатных видео
     ИЛИ галочку  repo  — если будете ПРОДАВАТЬ видео, приложения или обои
     (платные файлы хранятся в приватных репозиториях)
  4. Generate token → скопируйте токен (ghp_…)
Токен хранится только в config.json рядом с программой. Никому не передавайте этот файл.
Это НЕ тот токен, что на Render.
"""


def ensure_token(force=False):
    while True:
        if CFG.get("token") and not force:
            st, j, h = gh("GET", "/user")
            if st == 200:
                CFG["login"], CFG["user_id"] = j["login"], j["id"]
                save_config()
                scopes = h.get("x-oauth-scopes")
                CFG["scopes_repo"] = scopes is not None and "repo" in {x.strip() for x in scopes.split(",")}
                save_config()
                if scopes is not None and not {"public_repo", "repo"} & {s.strip() for s in scopes.split(",")}:
                    say("⚠ У токена нет права public_repo — создать репозиторий не получится. Создайте новый токен.")
                    force = True
                    continue
                return
            say(f"Сохранённый токен не принят GitHub ({st}).")
        say(TOKEN_HELP)
        tok = ask("Вставьте токен").strip().strip('"')
        tok = re.sub(r"^Bearer\s+", "", tok, flags=re.I)
        if not tok:
            raise Stop("Токен не введён")
        CFG["token"] = tok
        force = False


def ensure_site():
    if "site" not in CFG:
        s = ask("Адрес вашего сайта AnyTube (например https://anytube.onrender.com), Enter — пропустить")
        CFG["site"] = s.rstrip("/")
        save_config()
    return CFG.get("site", "")


# ─────────────────────────── видео: обработка ───────────────────────────
def probe_duration(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], quiet=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        raise Stop("FFmpeg не смог определить длительность видео")


def transcode(src, dst, target_bytes=None):
    """target_bytes=None — максимум качества (CRF 20); иначе двухпроходное сжатие под размер."""
    base = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", src]
    even = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    out = ["-pix_fmt", "yuv420p", "-movflags", "+faststart", dst]
    if target_bytes is None:
        say("  Конвертирую в MP4 (H.264, высокое качество)…")
        run(base + ["-vf", even, "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                    "-c:a", "aac", "-b:a", "160k"] + out)
        return
    dur = probe_duration(src)
    factor = 0.95
    for _ in range(3):
        total_kbps = target_bytes * 8 / 1000 / dur * factor
        a_kbps = 128 if total_kbps > 900 else 64
        v_kbps = int(total_kbps - a_kbps)
        if v_kbps < 120:
            raise Stop(f"Видео слишком длинное ({dur / 60:.0f} мин), чтобы уместить его в {human(target_bytes)} "
                       f"с приемлемым качеством. Выберите вариант с Git LFS или обрежьте видео.")
        if v_kbps < 700:
            vf = "scale=-2:'2*trunc(min(480,ih)/2)'"
        elif v_kbps < 1800:
            vf = "scale=-2:'2*trunc(min(720,ih)/2)'"
        elif v_kbps < 4500:
            vf = "scale=-2:'2*trunc(min(1080,ih)/2)'"
        else:
            vf = even
        say(f"  Сжимаю до ~{human(target_bytes)}: видео {v_kbps} кбит/с, звук {a_kbps} кбит/с (2 прохода)…")
        passlog = os.path.join(tempfile.gettempdir(), "anytube_2pass")
        enc = ["-vf", vf, "-c:v", "libx264", "-preset", "medium", "-b:v", f"{v_kbps}k",
               "-maxrate", f"{int(v_kbps * 1.6)}k", "-bufsize", f"{v_kbps * 2}k", "-passlogfile", passlog]
        run(base + enc + ["-pass", "1", "-an", "-pix_fmt", "yuv420p", "-f", "mp4", os.devnull])
        run(base + enc + ["-pass", "2", "-c:a", "aac", "-b:a", f"{a_kbps}k"] + out)
        if os.path.getsize(dst) <= target_bytes:
            return
        factor *= 0.9
        say(f"  Получилось {human(os.path.getsize(dst))} — чуть больше нужного, пересжимаю…")
    raise Stop("Не удалось уложиться в размер")


def place_file(src, dst):
    """Кладёт исходник в папку репозитория без лишнего копирования, если можно."""
    try:
        os.link(src, dst)
    except OSError:
        say("  Копирую файл…")
        shutil.copy2(src, dst)


def faststart(src, dst):
    """MP4 с индексом в начале — начинает играть сразу. Быстро, без перекодирования."""
    say("  Оптимизирую MP4 для просмотра онлайн (faststart)…")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-map", "0",
                        "-c", "copy", "-movflags", "+faststart", dst], capture_output=True)
    if r.returncode != 0 or not os.path.exists(dst):
        place_file(src, dst)


def rmtree(path):
    def onerror(func, p, _):
        os.chmod(p, stat.S_IWRITE)
        func(p)
    if os.path.isdir(path):
        shutil.rmtree(path, onerror=onerror)


def pick_file():
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(title="Выберите видео для AnyTube",
                                          filetypes=[("Видео", VIDEO_TYPES), ("Все файлы", "*.*")])
        root.destroy()
        return path
    except Exception:
        return ask("Путь к видеофайлу (можно перетащить файл в это окно)")


def repo_exists(name):
    st, _, _ = gh("GET", f"/repos/{CFG['login']}/{name}")
    return st == 200


def repo_empty(name):
    """Репозиторий есть, но в нём ни одного коммита (осталось от прерванной загрузки)."""
    st, _, _ = gh("GET", f"/repos/{CFG['login']}/{name}/commits?per_page=1")
    return st == 409


def repo_taken(name):
    return repo_exists(name) and not repo_empty(name)


def free_repo_name(name):
    """Свободное имя; пустые репозитории от прерванных загрузок используются повторно."""
    if not repo_taken(name):
        return name
    n = 2
    while repo_taken(f"{name}_{n}"):
        n += 1
    return f"{name}_{n}"


# ─────────────────────────── большие видео и описание ───────────────────────────
YEAR_SECONDS = 365 * 24 * 3600          # видео не может длиться больше 1 года
DESC_LIMIT = 1_000_000_000               # лимит описания — 1 000 000 000 символов
DESC_CHUNK = 10_000_000                  # описание хранится файлами по 10 млн символов (< 40 МБ)
VOLUME_BUDGET = 900 * MB                 # обычных файлов в одном репозитории-томе (GitHub: push до 2 ГБ)
LFS_PER_VOLUME = 2                       # частей LFS в одном томе
MAX_PARTS = 9999


def fmt_duration(sec):
    sec = int(sec)
    d, sec = divmod(sec, 86400)
    h, sec = divmod(sec, 3600)
    m, s = divmod(sec, 60)
    return (f"{d} дн. " if d else "") + f"{h:02d}:{m:02d}:{s:02d}"


def split_video(src, limit, out_dir, base, ext, allow_reencode=True):
    """Режет видео на пронумерованные части ≤ limit без перекодирования (по ключевым кадрам)."""
    dur = probe_duration(src)
    size = os.path.getsize(src)
    seg = max(2.0, dur * limit * 0.85 / size)
    fmt = "webm" if ext == ".webm" else "mp4"
    for attempt in range(5):
        rmtree(out_dir)
        os.makedirs(out_dir)
        if dur / seg > MAX_PARTS:
            raise Stop(f"Получилось бы больше {MAX_PARTS} частей — выберите вариант с Git LFS (части по 1.9 ГБ).")
        say(f"  Режу на части по ~{seg:.0f} с (≤ {human(limit)} каждая)…")
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src,
               "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", "-f", "segment",
               "-segment_time", f"{seg:.3f}", "-segment_start_number", "1",
               "-reset_timestamps", "1", "-avoid_negative_ts", "make_zero", "-segment_format", fmt]
        if fmt == "mp4":
            cmd += ["-segment_format_options", "movflags=+faststart"]
        run(cmd + [os.path.join(out_dir, f"{base}.part%04d{ext}")])
        parts = sorted(os.path.join(out_dir, f) for f in os.listdir(out_dir))
        biggest = max(os.path.getsize(p) for p in parts)
        if biggest <= limit:
            say(f"  Готово: {len(parts)} частей")
            return parts
        seg = seg * limit / biggest * 0.85
        if seg < 2:
            break
    if not allow_reencode:
        raise Stop("Не получилось нарезать видео на части нужного размера")
    # ключевые кадры слишком редкие — перекодируем с ключевым кадром каждые 2 секунды
    say("  В видео слишком редкие ключевые кадры — перекодирую, чтобы его можно было нарезать…")
    fixed = os.path.join(os.path.dirname(out_dir), "keyframes.mp4")
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", src,
         "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
         "-force_key_frames", "expr:gte(t,n_forced*2)", "-c:a", "aac", "-b:a", "160k",
         "-pix_fmt", "yuv420p", fixed])
    try:
        return split_video(fixed, limit, out_dir, base, ".mp4", allow_reencode=False)
    finally:
        pass  # fixed удалится вместе с рабочей папкой


def read_description(required=False):
    """Возвращает (путь_к_txt_или_None, текст_или_None)."""
    say("\n📝 ОПИСАНИЕ ВИДЕО (до 1 000 000 000 символов)")
    say("  • Просто пишите текст (можно в несколько строк). Закончить — строка из одной точки «.»")
    say("  • Или перетащите в это окно .txt файл и нажмите Enter")
    say("  • Или напишите  файл  — откроется окно выбора .txt")
    say("  • " + ("Пустая строка — отмена" if required else "Пустая строка сразу — без описания"))
    try:
        first = input("> ")
    except EOFError:
        first = ""
    cand = first.strip().strip('"').strip("'")
    if not cand:
        if required:
            raise Stop("Описание не введено")
        say("  (без описания)")
        return None, None
    if cand.lower() not in ("файл", "file", "f", "ф") and os.path.isfile(cand):
        say(f"  Беру описание из файла: {cand}")
        return cand, None
    if cand.lower() not in ("файл", "file", "f", "ф"):
        lines = [first] if cand != "." else []
        if cand != ".":
            while True:
                try:
                    line = input("> ")
                except EOFError:
                    break
                if line.strip() == ".":
                    break
                lines.append(line)
        text = "\n".join(lines).strip()
        if text:
            say(f"  Описание принято: {len(text):,} символов".replace(",", " "))
        return None, (text or None)
    if cand.lower() in ("файл", "file", "f", "ф"):  # окно выбора .txt
        try:
            import tkinter
            from tkinter import filedialog
            root = tkinter.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            p = filedialog.askopenfilename(title="Файл с описанием", filetypes=[("Текст", "*.txt *.md"), ("Все", "*.*")])
            root.destroy()
        except Exception:
            p = ask("Путь к .txt файлу")
        p = (p or "").strip().strip('"')
        if not p or not os.path.isfile(p):
            raise Stop("Файл описания не найден")
        return p, None
    return None, None


def write_description_chunks(desc_file, desc_text, out_dir):
    """Делит описание на пронумерованные файлы description.part0001.txt… Возвращает (список, всего_символов)."""
    os.makedirs(out_dir, exist_ok=True)
    chunks, total = [], 0

    def emit(piece):
        nonlocal total
        total += len(piece)
        if total > DESC_LIMIT:
            raise Stop(f"Описание длиннее {DESC_LIMIT:,} символов — сократите его.".replace(",", " "))
        name = f"description.part{len(chunks) + 1:04d}.txt"
        p = os.path.join(out_dir, name)
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(piece)
        chunks.append({"local": p, "path": name, "chars": len(piece), "bytes": os.path.getsize(p)})

    if desc_text:
        for i in range(0, len(desc_text), DESC_CHUNK):
            emit(desc_text[i:i + DESC_CHUNK])
    elif desc_file:
        say("  Читаю описание…")
        with open(desc_file, encoding="utf-8-sig", errors="replace", newline="") as f:
            while True:
                piece = f.read(DESC_CHUNK)
                if not piece:
                    break
                emit(piece)
    return chunks, total


def pack_volumes(items):
    """Раскладывает файлы по репозиториям-томам: ≤ VOLUME_BUDGET обычных байт и ≤ LFS_PER_VOLUME частей LFS."""
    vols, cur, plain, lfs = [], [], 0, 0
    for it in items:
        w_plain = 0 if it.get("lfs") else it["size"]
        w_lfs = 1 if it.get("lfs") else 0
        if cur and (plain + w_plain > VOLUME_BUDGET or lfs + w_lfs > LFS_PER_VOLUME):
            vols.append(cur)
            cur, plain, lfs = [], 0, 0
        cur.append(it)
        plain += w_plain
        lfs += w_lfs
    if cur:
        vols.append(cur)
    return vols


def push_repo(work, repo, description, files, lfs_files, topics, login, private=False):
    """Создаёт публичный репозиторий и отправляет туда файлы из папки work."""
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": description[:300], "private": bool(private),
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        if st == 422 and repo_empty(repo):
            say(f"  Репозиторий {repo} уже создан прошлой попыткой и пуст — использую его.")
            gh("PATCH", f"/repos/{login}/{repo}", {"description": description[:300], "private": bool(private)})
        else:
            raise Stop(f"GitHub не создал репозиторий {repo}: {gh_error(st, j)}")
    if topics:
        gh("PUT", f"/repos/{login}/{repo}/topics", {"names": topics})
    auth = base64.b64encode(f"{login}:{CFG['token']}".encode()).decode()
    git = lambda *a: run(["git", *a], cwd=work)
    try:
        git("init", "-q", "-b", "main")
    except Stop:  # старый Git (до 2.28) не знает -b
        git("init", "-q")
        git("symbolic-ref", "HEAD", "refs/heads/main")
    git("config", "user.name", login)
    git("config", "user.email", f"{CFG['user_id']}+{login}@users.noreply.github.com")
    git("config", "credential.helper", "")
    git("config", "http.https://github.com/.extraheader", f"AUTHORIZATION: basic {auth}")
    git("config", "http.postBuffer", "524288000")
    git("config", "lfs.locksverify", "false")
    if lfs_files:
        git("lfs", "install", "--local")
        for f in lfs_files:
            git("lfs", "track", f)
    git("add", "-A")
    nothing = lambda r: "nothing to commit" in ((r.stdout or "") + (r.stderr or ""))  # коммит уже сделан до сбоя
    run(["git", "commit", "-q", "-m", f"AnyTube: {description[:60]}"], cwd=work, ok_if=nothing)
    git("push", "-q", f"https://github.com/{login}/{repo}.git", "main")


# ─────────────────────────── загрузка: видео / приложение / обои ───────────────────────────
PAID_PREFIX = "anytubepaid_"              # приватные репозитории с платными файлами
SUB_PERIODS = {"hour": "час", "day": "день", "month": "месяц", "year": "год"}
APP_TYPES = "*.exe *.msi *.zip *.7z *.rar *.apk *.appx *.msix *.dmg *.deb *.AppImage *.jar"
WALL_TYPES = "*.mp4 *.webm *.gif *.mov *.mkv"


def platform_account():
    return (CFG.get("platform") or "alekandrza14").strip()


def kop(rub):
    """Рубли (строка/число) → копейки; пусто или 0 → None."""
    if rub in (None, ""):
        return None
    try:
        v = round(float(str(rub).replace(",", ".").replace(" ", "")) * 100)
    except ValueError:
        raise Stop(f"Неверная цена: {rub}")
    if v < 0:
        raise Stop("Цена не может быть отрицательной")
    return v or None


def normalize_sale(kind, sale):
    """Приводит настройки продажи к виду манифеста (копейки). Пусто → бесплатно."""
    sale = sale or {}
    out = {}
    if kind == "video":
        if kop(sale.get("per_hour")):
            out["per_hour"] = kop(sale["per_hour"])
        if kop(sale.get("buy")):
            out["buy"] = kop(sale["buy"])
    elif kind == "app":
        if kop(sale.get("buy")):
            out["buy"] = kop(sale["buy"])
        sub = {p: kop((sale.get("sub") or {}).get(p)) for p in SUB_PERIODS}
        sub = {p: v for p, v in sub.items() if v}
        if sub:
            out["sub"] = sub
    elif kind == "wallpaper":
        if kop(sale.get("buy")):
            out["buy"] = kop(sale["buy"])
    for k, v in list(out.items()):
        for x in (v.values() if isinstance(v, dict) else [v]):
            if x < 100 and not (k == "per_hour" and x >= 10):
                raise Stop("Минимальная цена — 1 ₽ (для почасового просмотра — 0,10 ₽/час)")
    return out


def make_clip(src, dst, seconds, preview=False):
    """Трейлер (первые N секунд без перекодирования) или лёгкое превью обоев (360p, без звука)."""
    if preview:
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-t", str(seconds),
             "-vf", "scale=-2:'2*trunc(min(360,ih)/2)'", "-c:v", "libx264", "-crf", "30", "-preset", "medium",
             "-an", "-pix_fmt", "yuv420p", "-movflags", "+faststart", dst])
    else:
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-t", str(seconds),
             "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", "-movflags", "+faststart", dst])


def video_to_parts(src_path, work, base, mode, duration):
    """Видео → список локальных частей (как раньше: целиком, нарезка на части, LFS или сжатие)."""
    ext = os.path.splitext(src_path)[1].lower()
    needs_convert = ext not in WEB_EXT
    out_ext = ".mp4" if needs_convert else ext
    if mode == "compress":
        dst = os.path.join(work, base + ".mp4")
        transcode(src_path, dst, PLAIN_LIMIT)
        return [dst], ".mp4", dst
    src = src_path
    if needs_convert:
        say(f"Формат {ext} плохо играет в браузерах — конвертирую в MP4.")
        src = os.path.join(work, "converted.mp4")
        transcode(src_path, src)
    limit = LFS_LIMIT if mode == "lfs" else PLAIN_LIMIT
    if os.path.getsize(src) <= limit:
        one = os.path.join(work, base + out_ext)
        if out_ext == ".mp4":
            faststart(src, one)
        else:
            place_file(src, one)
        return [one], out_ext, one
    say(f"Видео {human(os.path.getsize(src))} — делю на пронумерованные части.")
    parts = split_video(src, limit, os.path.join(work, "parts"), base, out_ext)
    return parts, out_ext, src


def upload_item(o):
    """
    o = {
      path, title, base, desc_file, desc_text, mode: plain|lfs|compress,
      kind: video|app|wallpaper,
      sale: {per_hour, buy, sub: {hour, day, month, year}}  (рубли; пусто — бесплатно),
      app_path (для kind=app), trailer (секунд, для платного видео)
    }
    """
    ensure_token()
    site = CFG.get("site", "")
    login = CFG["login"]
    path = (o.get("path") or "").strip().strip('"')
    if not path or not os.path.isfile(path):
        raise Stop("Видеофайл не выбран или не найден")
    kind = o.get("kind") or "video"
    sale = normalize_sale(kind, o.get("sale"))
    paid = bool(sale)
    app_path = (o.get("app_path") or "").strip().strip('"')
    if kind == "app":
        if not app_path or not os.path.isfile(app_path):
            raise Stop("Выберите файл приложения (установщик / архив)")
        if os.path.getsize(app_path) > LFS_LIMIT:
            raise Stop("Файл приложения больше 1.9 ГБ — GitHub его не примет. Упакуйте в архив по частям.")
    if paid and not CFG.get("scopes_repo"):
        raise Stop("Для продажи нужен токен с галочкой «repo» (платные файлы хранятся в ПРИВАТНЫХ репозиториях).\n"
                   "Создайте новый токен (Tokens classic → галочка repo) и вставьте его в настройках.")

    stem = os.path.splitext(os.path.basename(path))[0]
    title = (o.get("title") or stem).strip()[:300]
    base = slug(o.get("base") or stem)[:60]
    main_repo = free_repo_name(VIDEO_PREFIX + base)
    paid_repo = free_repo_name(PAID_PREFIX + base) if paid else None
    mode = o.get("mode") or "plain"

    ensure_ffmpeg()
    duration = probe_duration(path)
    say(f"\nФайл: {path}  ({human(os.path.getsize(path))}), длительность {fmt_duration(duration)}")
    if duration > YEAR_SECONDS:
        raise Stop("Видео длиннее 1 года — такие AnyTube не принимает.")
    kinds = {"video": "Видео", "app": "Реклама приложения", "wallpaper": "Анимированные обои"}
    say(f"Тип: {kinds[kind]} · {'ПЛАТНО: ' + sale_text(sale) if paid else 'бесплатно'}")

    work = os.path.join(TOOLS, "work", main_repo)
    rmtree(work)
    os.makedirs(work)
    try:
        public, private = [], []   # элементы для публичных и приватных репозиториев
        files_pub, files_paid = [], []

        def part_items(parts, full_duration):
            res = []
            for i, p in enumerate(parts, 1):
                s = os.path.getsize(p)
                res.append({"kind": "part", "local": p, "path": os.path.basename(p), "size": s, "lfs": s > PLAIN_LIMIT,
                            "duration": round(probe_duration(p), 3) if len(parts) > 1 else round(full_duration, 3)})
            return res

        def file_item(local, name=None):
            s = os.path.getsize(local)
            return {"kind": "file", "local": local, "path": name or os.path.basename(local), "size": s,
                    "lfs": s > PLAIN_LIMIT, "name": name or os.path.basename(local)}

        # 1. Видео
        parts, out_ext, full_src = video_to_parts(path, work, base, mode, duration)
        full = part_items(parts, duration)
        total_dur = sum(p["duration"] for p in full)
        if kind == "video" and paid:
            t = max(5, min(int(o.get("trailer") or 60), int(total_dur // 3) or 5))
            say(f"Платное видео: делаю бесплатный трейлер — первые {t} с.")
            tr = os.path.join(work, f"{base}.trailer{out_ext if out_ext in WEB_EXT else '.mp4'}")
            make_clip(full_src if os.path.exists(full_src) else parts[0], tr, t)
            public += part_items([tr], probe_duration(tr))
            private += full
        elif kind == "wallpaper" and paid:
            say("Платные обои: делаю лёгкое превью (6 с, 360p) для сайта.")
            pv = os.path.join(work, f"{base}.preview.mp4")
            make_clip(full_src if os.path.exists(full_src) else parts[0], pv, 6, preview=True)
            public += part_items([pv], probe_duration(pv))
            orig = os.path.join(work, "orig_" + os.path.basename(path))
            place_file(path, orig)
            it = file_item(orig, os.path.basename(path))
            private.append(it)
            files_paid.append(it)
            for p in parts:  # полное видео на сайт не нужно — в продаже исходный файл
                if os.path.exists(p) and p != path:
                    os.remove(p)
        else:
            public += full
            if kind == "wallpaper":  # бесплатные обои: скачивается исходный файл
                if os.path.splitext(path)[1].lower() in WEB_EXT and len(parts) == 1:
                    files_pub.append({**full[0], "kind": "part", "name": os.path.basename(path)})
                else:
                    orig = os.path.join(work, "orig_" + os.path.basename(path))
                    place_file(path, orig)
                    it = file_item(orig, os.path.basename(path))
                    public.append(it)
                    files_pub.append(it)
        if kind == "app":
            local = os.path.join(work, "app_" + os.path.basename(app_path))
            place_file(app_path, local)
            it = file_item(local, os.path.basename(app_path))
            (private if paid else public).append(it)
            (files_paid if paid else files_pub).append(it)
            say(f"Приложение: {it['name']} ({human(it['size'])}) — {'в приватный репозиторий' if paid else 'в открытый доступ'}")

        # 2. Описание
        chunks, desc_chars = write_description_chunks(o.get("desc_file"), o.get("desc_text"), os.path.join(work, "desc"))
        for c in chunks:
            public.append({"kind": "desc", "local": c["local"], "path": c["path"], "size": c["bytes"], "chars": c["chars"], "lfs": False})

        # 3. Тома
        vols = pack_volumes(public)
        names = [main_repo] + [f"{main_repo}_vol{k}" for k in range(2, len(vols) + 1)]
        pvols = pack_volumes(private) if private else []
        pnames = ([paid_repo] + [f"{paid_repo}_vol{k}" for k in range(2, len(pvols) + 1)]) if pvols else []
        for n in names[1:] + pnames[1:]:
            if repo_taken(n):
                raise Stop(f"Репозиторий {n} уже существует — выберите другое короткое имя.")
        for k, vol in enumerate(vols):
            for it in vol:
                it["repo"] = names[k]
        for k, vol in enumerate(pvols):
            for it in vol:
                it["repo"] = pnames[k]

        pick = lambda it, keys: {k: it[k] for k in keys if k in it}
        virtual = base + (out_ext if kind != "wallpaper" or not paid else ".mp4")
        watch = f"{site}/watch?v={urllib.parse.quote(f'{login}/{main_repo}/{virtual}', safe='')}" if site else ""
        manifest = {
            "anytube": 1, "kind": kind, "title": title, "file": virtual,
            "duration": round(total_dur, 3),
            "parts": [pick(it, ("repo", "path", "size", "duration", "lfs")) for it in public if it["kind"] == "part"],
            "description": {"chars": desc_chars, "chunks": [pick(it, ("repo", "path", "chars", "size")) for it in public if it["kind"] == "desc"]},
            "files": [pick(it, ("repo", "path", "size", "lfs", "name")) for it in files_pub],
        }
        if paid:
            manifest["sale"] = sale
            manifest["trailer"] = kind == "video"
            manifest["paid"] = {
                "parts": [pick(it, ("repo", "path", "size", "duration", "lfs")) for it in private if it["kind"] == "part"],
                "files": [pick(it, ("repo", "path", "size", "lfs", "name")) for it in files_paid],
            }

        def push(items, vdir, repo, rdesc, topics, private_repo=False):
            os.makedirs(vdir)
            for it in items:
                dst = os.path.join(vdir, it["path"])
                if it["local"] == path or it["local"] == app_path:
                    place_file(it["local"], dst)
                else:
                    os.replace(it["local"], dst)
            push_repo(vdir, repo, rdesc, [it["path"] for it in items], [it["path"] for it in items if it["lfs"]],
                      topics, login, private=private_repo)
            rmtree(vdir)

        total_steps = len(pvols) + len(vols)
        step = 0
        # 4. Сначала приватные (платные), потом тома, главный — последним
        for k, vol in enumerate(pvols):
            step += 1
            say(f"\n[{step}/{total_steps}] 🔒 Загружаю платные файлы в приватный {pnames[k]}…")
            push(vol, os.path.join(work, f"paid{k + 1}"), pnames[k], f"{title} — платные файлы AnyTube", [], private_repo=True)
            invite_platform(pnames[k])
        for k in list(range(1, len(vols))) + [0]:
            step += 1
            vdir = os.path.join(work, f"vol{k + 1}")
            if k == 0:
                os.makedirs(vdir)
                with open(os.path.join(vdir, "anytube.json"), "w", encoding="utf-8") as f:
                    json.dump(manifest, f, ensure_ascii=False, indent=1)
                with open(os.path.join(vdir, "README.md"), "w", encoding="utf-8") as f:
                    f.write(f"# {title}\n\n{kinds[kind]} на AnyTube"
                            + (f" · {sale_text(sale)}" if paid else "") + "\n" + (f"\nСмотреть: {watch}\n" if watch else ""))
                say(f"\n[{step}/{total_steps}] Загружаю {names[0]}…")
                for it in vols[0]:
                    dst = os.path.join(vdir, it["path"])
                    place_file(it["local"], dst) if it["local"] in (path, app_path) else os.replace(it["local"], dst)
                push_repo(vdir, names[0], title, [], [it["path"] for it in vols[0] if it["lfs"]], ["anytubevideo"], login)
                rmtree(vdir)
            else:
                say(f"\n[{step}/{total_steps}] Загружаю {names[k]}…")
                vd = os.path.join(work, f"vol{k + 1}")
                os.makedirs(vd)
                with open(os.path.join(vd, "anytube-volume.json"), "w", encoding="utf-8") as f:
                    json.dump({"main": f"{login}/{main_repo}", "volume": k + 1}, f)
                for it in vols[k]:
                    dst = os.path.join(vd, it["path"])
                    place_file(it["local"], dst) if it["local"] in (path, app_path) else os.replace(it["local"], dst)
                push_repo(vd, names[k], f"{title} — том {k + 1} (AnyTube)", [], [it["path"] for it in vols[k] if it["lfs"]], [], login)
                rmtree(vd)
    finally:
        rmtree(work)

    say(f"\n✅ Загружено: {title}")
    say(f"   Репозиторий: https://github.com/{login}/{main_repo}")
    if paid:
        say(f"   🔒 Платные файлы: {', '.join(pnames)} (приватно, доступ у {platform_account()} для сайта)")
    if watch:
        say(f"   На AnyTube:  {watch}")
    say("   ⏳ Видео отправлено на проверку модератору — в ленте AnyTube оно появится после одобрения.")
    say("   По ссылке выше вы уже можете его посмотреть (войдя на сайт через GitHub).")
    return watch


def sale_text(sale):
    r = lambda k: f"{k / 100:g} ₽".replace(".", ",")
    parts = []
    if sale.get("per_hour"):
        parts.append(f"{r(sale['per_hour'])}/час просмотра")
    if sale.get("buy"):
        parts.append(f"покупка {r(sale['buy'])}")
    for p, v in (sale.get("sub") or {}).items():
        parts.append(f"подписка {r(v)}/{SUB_PERIODS[p]}")
    return ", ".join(parts) or "бесплатно"


def invite_platform(repo):
    """Даёт аккаунту сайта доступ на чтение к приватному репозиторию (сайт сам примет приглашение)."""
    login, plat = CFG["login"], platform_account()
    if login.lower() == plat.lower():
        return
    st, j, _ = gh("PUT", f"/repos/{login}/{repo}/collaborators/{plat}", {"permission": "pull"})
    if st == 422:  # для личных репозиториев GitHub не всегда принимает permission — приглашаем без него
        st, j, _ = gh("PUT", f"/repos/{login}/{repo}/collaborators/{plat}", {})
    if st in (201, 204):
        say(f"   🔑 Сайту ({plat}) выдан доступ к {repo}" + (" (уже был)" if st == 204 else ""))
        return True
    say(f"⚠ Не удалось пригласить {plat} в {repo}: {gh_error(st, j)}.")
    say("   Загрузка продолжится. Потом нажмите в «Настройках» «🔑 Дать сайту доступ к платным файлам»,")
    say(f"   или вручную: github.com/{login}/{repo}/settings/access → Add people → {plat}.")
    return False


def reinvite_all():
    """Повторно приглашает аккаунт сайта во все ваши приватные репозитории anytubepaid_*."""
    ensure_token()
    login = CFG["login"]
    if login.lower() == platform_account().lower():
        say("Вы и есть аккаунт сайта — доступ не нужен.")
        return
    repos, page = [], 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&visibility=all&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список репозиториев: {gh_error(st, j)}")
        repos += [r["name"] for r in j if r["name"].lower().startswith(PAID_PREFIX)]
        if len(j) < 100:
            break
        page += 1
    if not repos:
        say("Платных репозиториев anytubepaid_… не найдено.")
        return
    ok = sum(1 for r in repos if invite_platform(r))
    say(f"\n✅ Доступ выдан: {ok} из {len(repos)}. Сайт примет приглашения сам в течение 5 минут.")


# ── консольный вариант (для запуска без окна) ──
def upload_video(path=None):
    ensure_token()
    ensure_site()
    path = (path or pick_file() or "").strip().strip('"')
    if not path or not os.path.isfile(path):
        raise Stop("Файл не выбран или не найден")
    stem = os.path.splitext(os.path.basename(path))[0]
    o = {"path": path, "title": ask("Название", stem)}
    o["base"] = ask("Короткое имя для ссылки (латиница)", slug(stem))
    say("Тип: 1 — видео, 2 — реклама приложения, 3 — анимированные обои")
    o["kind"] = {"2": "app", "3": "wallpaper"}.get(ask("Тип", "1"), "video")
    sale = {}
    if o["kind"] == "video":
        sale["per_hour"] = ask("Цена за час просмотра, ₽ (Enter — бесплатно)", "")
        sale["buy"] = ask("Цена покупки навсегда, ₽ (Enter — нет)", "")
    elif o["kind"] == "app":
        o["app_path"] = ask("Путь к файлу приложения")
        sale["buy"] = ask("Цена покупки, ₽ (Enter — нет)", "")
        sale["sub"] = {p: ask(f"Подписка за {n}, ₽ (Enter — нет)", "") for p, n in SUB_PERIODS.items()}
    else:
        sale["buy"] = ask("Цена обоев, ₽ (Enter — бесплатно)", "")
    o["sale"] = sale
    o["desc_file"], o["desc_text"] = read_description()
    size = os.path.getsize(path)
    if size > PLAIN_LIMIT or os.path.splitext(path)[1].lower() not in WEB_EXT:
        say("Как загрузить большое видео? 1 — части по 95 МБ [рекомендуется], 2 — Git LFS, 3 — сжать до 95 МБ")
        o["mode"] = {"2": "lfs", "3": "compress"}.get(ask("Выбор", "1"), "plain")
    upload_item(o)


# ─────────────────────────── описание у готового видео ───────────────────────────
def parse_video_ref_full(ref):
    """(владелец, репозиторий) из ссылки AnyTube, 'ник/репо/файл', 'ник/репо' или ссылки GitHub."""
    ref = ref.strip().strip('"')
    if "v=" in ref:
        ref = urllib.parse.parse_qs(urllib.parse.urlparse(ref).query).get("v", [""])[0]
    ref = re.sub(r"^https?://(www\.)?github\.com/", "", urllib.parse.unquote(ref)).strip("/")
    parts = [p for p in ref.split("/") if p]
    if len(parts) < 2 or not parts[1].lower().startswith(VIDEO_PREFIX):
        raise Stop("Не понял, какое видео. Вставьте ссылку со страницы видео на AnyTube "
                   "или ссылку на репозиторий anytubevideo_… на GitHub.")
    return parts[0], parts[1]


def add_description(ref=None, desc_file=None, desc_text=None):
    ensure_token()
    owner, repo = parse_video_ref_full(ref or ask("Ссылка на ВАШЕ видео (AnyTube или GitHub)"))
    login = CFG["login"]
    if owner.lower() != login.lower():
        raise Stop(f"Это видео пользователя {owner}. Описание можно менять только у своих видео.")
    st, info, _ = gh("GET", f"/repos/{login}/{repo}")
    if st != 200:
        raise Stop(f"Репозиторий {login}/{repo} не найден: {gh_error(st, info)}")
    branch = info["default_branch"]
    say(f"Видео: {info.get('description') or repo}")
    if not desc_file and not desc_text:
        desc_file, desc_text = read_description(required=True)

    work = os.path.join(TOOLS, "work", repo + "_desc")
    rmtree(work)
    os.makedirs(work)
    try:
        chunks, total = write_description_chunks(desc_file, desc_text, os.path.join(work, "new"))
        if not chunks:
            raise Stop("Описание пустое")
        ensure_git()
        auth = base64.b64encode(f"{login}:{CFG['token']}".encode()).decode()
        hdr = f"http.https://github.com/.extraheader=AUTHORIZATION: basic {auth}"
        clone = os.path.join(work, "repo")
        say("Скачиваю служебные файлы репозитория (без видео)…")
        env_skip = dict(os.environ, GIT_LFS_SKIP_SMUDGE="1")
        r = subprocess.run(["git", "-c", hdr, "-c", "credential.helper=", "clone", "-q", "--depth", "1",
                            "--filter=blob:none", "--no-checkout", "-b", branch,
                            f"https://github.com/{login}/{repo}.git", clone],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", env=env_skip)
        if r.returncode != 0:
            raise Stop("Не удалось скачать репозиторий:\n" + (r.stderr or r.stdout)[-600:])
        git = lambda *a: subprocess.run(["git", *a], cwd=clone, env=env_skip, capture_output=True,
                                        text=True, encoding="utf-8", errors="replace")
        git("config", "user.name", login)
        git("config", "user.email", f"{CFG['user_id']}+{login}@users.noreply.github.com")
        git("config", "credential.helper", "")
        git("config", "http.https://github.com/.extraheader", f"AUTHORIZATION: basic {auth}")
        git("config", "http.postBuffer", "524288000")
        git("sparse-checkout", "set", "--no-cone", "/anytube.json", "/description*", "/README.md")
        r = git("checkout", "-q", branch)
        if r.returncode != 0:
            raise Stop("Не удалось подготовить репозиторий:\n" + (r.stderr or "")[-600:])

        # старое описание в главном репозитории удаляем
        for f in os.listdir(clone):
            if re.match(r"^description(\.part\d+)?\.(txt|md)$", f, re.I):
                git("rm", "-q", "--", f)

        # раскладываем куски: в главный репозиторий до VOLUME_BUDGET, остальное — в тома _descN
        budget, groups, cur, used = VOLUME_BUDGET, [], [], 0
        for c in chunks:
            if cur and used + c["bytes"] > budget:
                groups.append(cur)
                cur, used = [], 0
            cur.append(c)
            used += c["bytes"]
        groups.append(cur)
        names = [repo]
        for k in range(2, len(groups) + 1):
            n = f"{repo}_desc{k}"
            while repo_exists(n):
                n += "x"
            names.append(n)
        for k, g in enumerate(groups):
            for c in g:
                c["repo"] = names[k]

        manifest_path = os.path.join(clone, "anytube.json")
        manifest = None
        if os.path.exists(manifest_path):
            with open(manifest_path, encoding="utf-8") as f:
                manifest = json.load(f)
        elif len(groups) > 1:
            # обычный репозиторий + описание в нескольких репозиториях → нужен anytube.json со списком
            st, tree, _ = gh("GET", f"/repos/{login}/{repo}/git/trees/{urllib.parse.quote(branch)}?recursive=1")
            vids = [b for b in (tree or {}).get("tree", []) if b.get("type") == "blob"
                    and re.search(r"\.(mp4|webm|ogg|ogv|mov|m4v)$", b["path"], re.I)]
            if not vids:
                raise Stop("В репозитории не найдено видео")
            manifest = {"anytube": 1, "title": info.get("description") or repo, "file": vids[0]["path"],
                        "duration": 0, "parts": [{"repo": repo, "path": vids[0]["path"], "size": vids[0]["size"],
                                                  "duration": 0, "lfs": vids[0]["size"] < 300}]}
        if manifest is not None:
            manifest["description"] = {"chars": total, "chunks": [
                {"repo": c["repo"], "path": c["path"], "chars": c["chars"], "size": c["bytes"]} for c in chunks]}

        # сначала тома с описанием, главный репозиторий — последним
        for k in range(1, len(groups)):
            vdir = os.path.join(work, f"descvol{k + 1}")
            os.makedirs(vdir)
            for c in groups[k]:
                os.replace(c["local"], os.path.join(vdir, c["path"]))
            with open(os.path.join(vdir, "anytube-volume.json"), "w", encoding="utf-8") as f:
                json.dump({"main": f"{login}/{repo}", "volume": k + 1, "kind": "description"}, f)
            say(f"\n[{k}/{len(groups)}] Загружаю описание, том {k + 1}: {names[k]}…")
            push_repo(vdir, names[k], f"Описание — том {k + 1} (AnyTube)", [], [], [], login)
            rmtree(vdir)
        for c in groups[0]:
            os.replace(c["local"], os.path.join(clone, c["path"]))
        if manifest is not None:
            with open(manifest_path, "w", encoding="utf-8") as f:
                json.dump(manifest, f, ensure_ascii=False, indent=1)
        r = git("add", "--sparse", "-A")
        if r.returncode != 0:
            git("add", "-A")
        r = git("commit", "-q", "-m", "AnyTube: описание")
        if r.returncode != 0 and "nothing to commit" not in (r.stdout + r.stderr):
            raise Stop("Не удалось сохранить изменения:\n" + (r.stderr or r.stdout)[-600:])
        say(f"\n[{len(groups)}/{len(groups)}] Загружаю описание в {repo}…")
        r = subprocess.run(["git", "push", "-q", "origin", branch], cwd=clone, env=env_skip)
        if r.returncode != 0:
            raise Stop("GitHub не принял изменения (push)")
    finally:
        rmtree(work)
    say(f"\n✅ Описание сохранено: {total:,} символов".replace(",", " "))
    say(f"   https://github.com/{login}/{repo}")
    say("   На сайте обновится в течение ~10 минут.")


# ─────────────────────────── комментарии ───────────────────────────
def parse_video_ref(ref):
    """Принимает ссылку AnyTube (…/watch?v=…), id 'автор/репо/файл.mp4' или 'автор/файл.mp4'."""
    ref = ref.strip().strip('"')
    if "v=" in ref:
        ref = urllib.parse.parse_qs(urllib.parse.urlparse(ref).query).get("v", [""])[0]
    ref = urllib.parse.unquote(ref).strip("/")
    parts = [p for p in ref.split("/") if p]
    if len(parts) < 2:
        raise Stop("Не понял, к какому видео комментарий. Вставьте ссылку со страницы видео на AnyTube.")
    return parts[0], parts[-1]


def comment_stem(author, file_name):
    head = f"{COMMENT_PREFIX}{author}_"
    tail = "_Comment."
    file_part = safe_file_part(file_name)[: 100 - len(head) - len(tail) - 4]
    return f"{head}{file_part}{tail}"


def next_comment_number(stem):
    nums = [0]
    page = 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список ваших репозиториев: {gh_error(st, j)}")
        for r in j:
            if r["name"].lower().startswith(stem.lower()):
                tail = r["name"][len(stem):]
                if tail.isdigit():
                    nums.append(int(tail))
        if len(j) < 100:
            return max(nums) + 1
        page += 1


def post_comment(ref=None, text=None):
    ensure_token()
    author, file_name = parse_video_ref(ref or ask("Ссылка на видео AnyTube (или автор/репозиторий/файл.mp4)"))
    say(f"Комментарий к видео {file_name} автора {author}.")
    if text is None:
        say("Напишите комментарий. Чтобы закончить — пустая строка.")
        lines = []
        while True:
            try:
                line = input()
            except EOFError:
                break
            if not line.strip():
                break
            lines.append(line)
        text = "\n".join(lines)
    text = (text or "").strip()
    if not text:
        raise Stop("Пустой комментарий не отправлен")

    login = CFG["login"]
    stem = comment_stem(author, file_name)
    num = next_comment_number(stem)
    repo = f"{stem}{num}"
    say(f"Создаю {login}/{repo}…")
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": " ".join(text.split())[:300], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
    gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubecomment"]})
    body = f"---\nvideo_author: {author}\nvideo_file: {file_name}\n---\n\n{text}\n"
    st, j, _ = gh("PUT", f"/repos/{login}/{repo}/contents/comment.md", {
        "message": "AnyTube comment", "content": base64.b64encode(body.encode()).decode(),
    })
    if st not in (200, 201):
        say(f"⚠ Полный текст не сохранился ({gh_error(st, j)}), но короткая версия есть в описании.")
    say(f"\n✅ Комментарий №{num} опубликован: https://github.com/{login}/{repo}")
    say("   На сайте появится в течение ~10 минут. Удалить — удалите этот репозиторий.")


# ─────────────────────────── дизлайки ───────────────────────────
# Дизлайк = репозиторий:  ваш_ник/anytubecomment_<автор>_<файл>_Commet.<уровень 1–5>.diske
# От одного человека к одному видео считается один дизлайк; повторный — меняет уровень.
DISLIKE_LEVELS = {
    1: "😕 Ну не очень",
    2: "😒 Так себе",
    3: "👎 Плохо",
    4: "😖 Очень плохо, зря потратил время",
    5: "🤮 Это убогий видос, мой день испорчен",
}
DISLIKE_RE = re.compile(r"_(?:Comment|Commet|Coment)\.([0-5])\.(?:diske|dislike|dizlike)$", re.I)


def dislike_stem(author, file_name):
    head = f"{COMMENT_PREFIX}{author}_"
    tail = "_Commet."
    file_part = safe_file_part(file_name)[: 100 - len(head) - len(tail) - len("5.diske")]
    return f"{head}{file_part}{tail}"


def my_dislikes(author, file_name):
    """Ваши уже поставленные дизлайки к этому видео (обычно 0 или 1)."""
    head = f"{COMMENT_PREFIX}{author}_{safe_file_part(file_name)}".lower()
    short = dislike_stem(author, file_name)[:-len("_Commet.")].lower()  # имя могло быть обрезано
    found, page = [], 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список ваших репозиториев: {gh_error(st, j)}")
        for r in j:
            m = DISLIKE_RE.search(r["name"])
            if m and r["name"][:m.start()].lower() in (head, short):
                found.append((r["name"], int(m.group(1))))
        if len(j) < 100:
            return found
        page += 1


def post_dislike(ref=None, level=None):
    ensure_token()
    author, file_name = parse_video_ref(ref or ask("Ссылка на видео AnyTube (или автор/репозиторий/файл.mp4)"))
    login = CFG["login"]
    if author.lower() == login.lower():
        raise Stop("Своему видео дизлайк поставить нельзя")
    existing = my_dislikes(author, file_name)
    say(f"\nДизлайк видео {file_name} автора {author}.")
    if existing:
        say(f"Сейчас у вас стоит: {DISLIKE_LEVELS.get(existing[0][1], existing[0][1])}")
    for lvl, label in DISLIKE_LEVELS.items():
        say(f"  {lvl} — {label}")
    if existing:
        say("  0 — убрать дизлайк")
    c = str(level) if level is not None else ask("Уровень дизлайка", "")
    if not c.isdigit() or int(c) not in DISLIKE_LEVELS and not (existing and c == "0"):
        raise Stop("Нужно число от 1 до 5")
    level = int(c)

    if existing:
        old, _ = existing[0]
        if level == 0:
            st, j, _ = gh("DELETE", f"/repos/{login}/{old}")
            if st == 204:
                say("✅ Дизлайк убран.")
            else:
                say("Токену не хватает права удалять репозитории (delete_repo).")
                say(f"Удалите репозиторий вручную: https://github.com/{login}/{old}/settings  (внизу «Delete this repository»)")
            return
        new = f"{dislike_stem(author, file_name)}{level}.diske"
        if new != old:
            st, j, _ = gh("PATCH", f"/repos/{login}/{old}", {"name": new, "description": DISLIKE_LEVELS[level]})
            if st != 200:
                raise Stop(f"GitHub не переименовал репозиторий: {gh_error(st, j)}")
        say(f"\n✅ Дизлайк изменён: {DISLIKE_LEVELS[level]}")
        say(f"   https://github.com/{login}/{new}")
        return

    repo = f"{dislike_stem(author, file_name)}{level}.diske"
    say(f"Создаю {login}/{repo}…")
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": DISLIKE_LEVELS[level], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
    gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubedislike"]})
    say(f"\n✅ Дизлайк поставлен: {DISLIKE_LEVELS[level]}")
    say(f"   https://github.com/{login}/{repo}")
    say("   На сайте появится в течение ~10 минут. Изменить уровень — снова выберите «Дизлайк».")


# ─────────────────────────── меню ───────────────────────────
def main():
    say("═══════════ AnyTube Uploader ═══════════")
    args = [a for a in sys.argv[1:] if a.strip()]
    if args:  # видео перетащили на AnyTube.cmd
        for p in args:
            try:
                upload_video(p)
            except Stop as e:
                say(f"\n❌ {e}")
        return
    while True:
        say(f"\n{'Аккаунт: ' + CFG['login'] if CFG.get('login') else 'Аккаунт: не подключён'}")
        say("  1 — Загрузить видео")
        say("  2 — Добавить / изменить описание у своего видео")
        say("  3 — Написать комментарий к видео")
        say("  4 — Поставить дизлайк (5 уровней)")
        say("  5 — Сменить токен GitHub")
        say("  6 — Сменить адрес сайта")
        say("  💰 Букс (реклама видео и заработок на просмотрах) — на сайте, страница /bux")
        say("  0 — Выход")
        c = ask("Выбор", "1")
        try:
            if c == "1":
                upload_video()
            elif c == "2":
                add_description()
            elif c == "3":
                post_comment()
            elif c == "4":
                post_dislike()
            elif c == "5":
                ensure_token(force=True)
                say(f"Подключён аккаунт {CFG['login']}")
            elif c == "6":
                CFG.pop("site", None)
                ensure_site()
            elif c == "0":
                return
        except Stop as e:
            say(f"\n❌ {e}")
        except KeyboardInterrupt:
            say("\nОтменено.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
