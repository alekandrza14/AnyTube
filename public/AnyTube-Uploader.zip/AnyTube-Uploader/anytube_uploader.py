#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AnyTube Uploader — загружает видео и комментарии на GitHub для сайта AnyTube.

  Видео:       <ваш_ник>/anytubevideo_<имя>          с файлом <имя>.mp4
  Комментарий: <ваш_ник>/anytubecomment_<автор>_<файл>_Comment.<N>

Сам скачивает всё нужное (Windows): портативный Git, Git LFS, FFmpeg.
Только стандартная библиотека Python, pip не нужен.
Запуск: AnyTube.cmd (или перетащите видео на AnyTube.cmd).
"""
import base64
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(APP_DIR, "tools")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
IS_WIN = os.name == "nt"

VIDEO_PREFIX = "anytubevideo_"
COMMENT_PREFIX = "anytubecomment_"
MB = 1024 ** 2
PLAIN_LIMIT = 95 * MB        # GitHub не принимает обычные файлы больше 100 МБ
LFS_LIMIT = 1950 * MB        # Git LFS на бесплатном GitHub — до 2 ГБ на файл
WEB_EXT = {".mp4", ".webm"}  # играют во всех браузерах; остальное конвертируем в mp4
VIDEO_TYPES = "*.mp4 *.webm *.mov *.m4v *.mkv *.avi *.wmv *.flv *.3gp *.ts *.mpg *.mpeg *.ogv"

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
os.makedirs(TOOLS, exist_ok=True)
os.environ["GIT_TERMINAL_PROMPT"] = "0"
os.environ["GCM_INTERACTIVE"] = "never"


# ─────────────────────────── мелочи ───────────────────────────
class Stop(Exception):
    """Понятная пользователю ошибка: показать и вернуться в меню."""


def say(*a):
    print(*a, flush=True)


def ask(prompt, default=""):
    hint = f" [{default}]" if default else ""
    try:
        s = input(f"{prompt}{hint}: ").strip()
    except EOFError:
        s = ""
    return s or default


def human(n):
    return f"{n / MB:.1f} МБ" if n < 1024 * MB else f"{n / 1024 / MB:.2f} ГБ"


def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config():
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(CFG, f, ensure_ascii=False, indent=2)


CFG = load_config()

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
    "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya", "і": "i", "ї": "yi", "є": "ye", "ґ": "g",
}


def slug(text):
    """Имя для GitHub: только латиница, цифры, '-' и '_'."""
    s = "".join(TRANSLIT.get(c, c) for c in text.lower())
    s = re.sub(r"[^a-z0-9-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_-")
    return s or "video"


def safe_file_part(name):
    """Так же, как сайт, приводим имя файла к символам, допустимым в имени репозитория."""
    return re.sub(r"[^A-Za-z0-9._-]", "-", name)


# ─────────────────────────── сеть / GitHub API ───────────────────────────
def http(method, url, data=None, token=None):
    headers = {"User-Agent": "anytube-uploader", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None), {k.lower(): v for k, v in r.headers.items()}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw)
        except Exception:
            j = {"message": raw.decode(errors="replace")[:300]}
        return e.code, j, {k.lower(): v for k, v in e.headers.items()}
    except urllib.error.URLError as e:
        raise Stop(f"Нет связи с {urllib.parse.urlparse(url).netloc}: {e.reason}")


def gh(method, path, data=None):
    return http(method, "https://api.github.com" + path, data, token=CFG.get("token"))


def gh_error(st, j):
    msg = (j or {}).get("message", "")
    errs = "; ".join(str(e.get("message") or e) for e in (j or {}).get("errors", []) if e)
    return f"{st} {msg}{' — ' + errs if errs else ''}"


def download(url, dest):
    say(f"  Скачиваю: {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "anytube-uploader"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest + ".part", "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r  {done * 100 // total:3d}%  {done // MB}/{total // MB} МБ", end="", flush=True)
    print()
    os.replace(dest + ".part", dest)


def latest_asset(repo, pattern):
    st, j, _ = http("GET", f"https://api.github.com/repos/{repo}/releases/latest")
    if st != 200:
        raise Stop(f"Не удалось узнать последнюю версию {repo}: {gh_error(st, j)}")
    for a in j.get("assets", []):
        if re.search(pattern, a["name"]):
            return a["browser_download_url"]
    raise Stop(f"В релизе {repo} нет подходящего файла")


# ─────────────────────────── инструменты ───────────────────────────
def add_path(*dirs):
    have = os.environ.get("PATH", "").split(os.pathsep)
    new = [d for d in dirs if os.path.isdir(d) and d not in have]
    if new:
        os.environ["PATH"] = os.pathsep.join(new + have)


def works(cmd):
    try:
        return subprocess.run(cmd, capture_output=True).returncode == 0
    except OSError:
        return False


def run(cmd, cwd=None, quiet=False):
    r = subprocess.run(cmd, cwd=cwd, capture_output=quiet, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        tail = ((r.stderr or "") + (r.stdout or ""))[-800:] if quiet else ""
        raise Stop(f"Команда завершилась с ошибкой ({r.returncode}): {' '.join(cmd[:3])} …\n{tail}")
    return r


def extract_from_zip(zip_path, wanted, dest_dir):
    """Достаёт из архива файлы с именами из wanted (где бы они ни лежали)."""
    os.makedirs(dest_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for m in zf.namelist():
            name = m.rsplit("/", 1)[-1]
            if name in wanted:
                with zf.open(m) as s, open(os.path.join(dest_dir, name), "wb") as d:
                    shutil.copyfileobj(s, d)


def ensure_git():
    pg = os.path.join(TOOLS, "PortableGit")
    lfs_dir = os.path.join(TOOLS, "git-lfs")
    add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"), lfs_dir)
    if not works(["git", "--version"]):
        if not IS_WIN:
            raise Stop("Git не найден. Установите: sudo apt install git git-lfs  (или brew install git git-lfs)")
        say("Git не найден — скачиваю портативный Git for Windows (один раз, ~60 МБ)…")
        url = latest_asset("git-for-windows/git", r"^PortableGit-[\d.]+-64-bit\.7z\.exe$")
        exe = os.path.join(TOOLS, "PortableGit.7z.exe")
        download(url, exe)
        say("  Распаковываю Git…")
        subprocess.run([exe, "-o" + pg, "-y"], check=True)
        os.remove(exe)
        add_path(os.path.join(pg, "cmd"), os.path.join(pg, "mingw64", "bin"))
    if not works(["git", "lfs", "version"]):
        if not IS_WIN:
            raise Stop("Git LFS не найден. Установите: sudo apt install git-lfs  (или brew install git-lfs)")
        say("Git LFS не найден — скачиваю (один раз, ~10 МБ)…")
        url = latest_asset("git-lfs/git-lfs", r"^git-lfs-windows-amd64-v[\d.]+\.zip$")
        z = os.path.join(TOOLS, "git-lfs.zip")
        download(url, z)
        extract_from_zip(z, {"git-lfs.exe"}, lfs_dir)
        os.remove(z)
        add_path(lfs_dir)
        if not works(["git", "lfs", "version"]):
            raise Stop("Git LFS так и не запустился")


def ensure_ffmpeg(required=True):
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if works(["ffmpeg", "-version"]) and works(["ffprobe", "-version"]):
        return True
    if not required:
        return False
    if not IS_WIN:
        raise Stop("FFmpeg не найден. Установите: sudo apt install ffmpeg  (или brew install ffmpeg)")
    say("FFmpeg не найден — скачиваю (один раз, ~150 МБ)…")
    url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
    z = os.path.join(TOOLS, "ffmpeg.zip")
    download(url, z)
    say("  Распаковываю FFmpeg…")
    extract_from_zip(z, {"ffmpeg.exe", "ffprobe.exe"}, os.path.join(TOOLS, "ffmpeg", "bin"))
    os.remove(z)
    add_path(os.path.join(TOOLS, "ffmpeg", "bin"))
    if not works(["ffmpeg", "-version"]):
        raise Stop("FFmpeg так и не запустился")
    return True


# ─────────────────────────── токен ───────────────────────────
TOKEN_HELP = """
Нужен токен GitHub, чтобы создавать репозитории от вашего имени.
  1. Откройте https://github.com/settings/tokens/new  (Tokens (classic))
  2. Note: AnyTube Uploader, Expiration: на ваш выбор
  3. Отметьте галочку  public_repo  (больше ничего не нужно)
  4. Generate token → скопируйте токен (ghp_…)
Токен хранится только в config.json рядом с программой. Никому не передавайте этот файл.
Это НЕ тот токен, что на Render: тому права не нужны, этому нужен public_repo.
"""


def ensure_token(force=False):
    while True:
        if CFG.get("token") and not force:
            st, j, h = gh("GET", "/user")
            if st == 200:
                CFG["login"], CFG["user_id"] = j["login"], j["id"]
                save_config()
                scopes = h.get("x-oauth-scopes")
                if scopes is not None and not {"public_repo", "repo"} & {s.strip() for s in scopes.split(",")}:
                    say("⚠ У токена нет права public_repo — создать репозиторий не получится. Создайте новый токен.")
                    force = True
                    continue
                return
            say(f"Сохранённый токен не принят GitHub ({st}).")
        say(TOKEN_HELP)
        tok = ask("Вставьте токен").strip().strip('"')
        tok = re.sub(r"^Bearer\s+", "", tok, flags=re.I)
        if not tok:
            raise Stop("Токен не введён")
        CFG["token"] = tok
        force = False


def ensure_site():
    if "site" not in CFG:
        s = ask("Адрес вашего сайта AnyTube (например https://anytube.onrender.com), Enter — пропустить")
        CFG["site"] = s.rstrip("/")
        save_config()
    return CFG.get("site", "")


# ─────────────────────────── видео: обработка ───────────────────────────
def probe_duration(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], quiet=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        raise Stop("FFmpeg не смог определить длительность видео")


def transcode(src, dst, target_bytes=None):
    """target_bytes=None — максимум качества (CRF 20); иначе двухпроходное сжатие под размер."""
    base = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", src]
    even = "scale=trunc(iw/2)*2:trunc(ih/2)*2"
    out = ["-pix_fmt", "yuv420p", "-movflags", "+faststart", dst]
    if target_bytes is None:
        say("  Конвертирую в MP4 (H.264, высокое качество)…")
        run(base + ["-vf", even, "-c:v", "libx264", "-preset", "medium", "-crf", "20",
                    "-c:a", "aac", "-b:a", "160k"] + out)
        return
    dur = probe_duration(src)
    factor = 0.95
    for _ in range(3):
        total_kbps = target_bytes * 8 / 1000 / dur * factor
        a_kbps = 128 if total_kbps > 900 else 64
        v_kbps = int(total_kbps - a_kbps)
        if v_kbps < 120:
            raise Stop(f"Видео слишком длинное ({dur / 60:.0f} мин), чтобы уместить его в {human(target_bytes)} "
                       f"с приемлемым качеством. Выберите вариант с Git LFS или обрежьте видео.")
        if v_kbps < 700:
            vf = "scale=-2:'2*trunc(min(480,ih)/2)'"
        elif v_kbps < 1800:
            vf = "scale=-2:'2*trunc(min(720,ih)/2)'"
        elif v_kbps < 4500:
            vf = "scale=-2:'2*trunc(min(1080,ih)/2)'"
        else:
            vf = even
        say(f"  Сжимаю до ~{human(target_bytes)}: видео {v_kbps} кбит/с, звук {a_kbps} кбит/с (2 прохода)…")
        passlog = os.path.join(tempfile.gettempdir(), "anytube_2pass")
        enc = ["-vf", vf, "-c:v", "libx264", "-preset", "medium", "-b:v", f"{v_kbps}k",
               "-maxrate", f"{int(v_kbps * 1.6)}k", "-bufsize", f"{v_kbps * 2}k", "-passlogfile", passlog]
        run(base + enc + ["-pass", "1", "-an", "-pix_fmt", "yuv420p", "-f", "mp4", os.devnull])
        run(base + enc + ["-pass", "2", "-c:a", "aac", "-b:a", f"{a_kbps}k"] + out)
        if os.path.getsize(dst) <= target_bytes:
            return
        factor *= 0.9
        say(f"  Получилось {human(os.path.getsize(dst))} — чуть больше нужного, пересжимаю…")
    raise Stop("Не удалось уложиться в размер")


def place_file(src, dst):
    """Кладёт исходник в папку репозитория без лишнего копирования, если можно."""
    try:
        os.link(src, dst)
    except OSError:
        say("  Копирую файл…")
        shutil.copy2(src, dst)


def faststart(src, dst):
    """MP4 с индексом в начале — начинает играть сразу. Быстро, без перекодирования."""
    say("  Оптимизирую MP4 для просмотра онлайн (faststart)…")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src, "-map", "0",
                        "-c", "copy", "-movflags", "+faststart", dst], capture_output=True)
    if r.returncode != 0 or not os.path.exists(dst):
        place_file(src, dst)


def rmtree(path):
    def onerror(func, p, _):
        os.chmod(p, stat.S_IWRITE)
        func(p)
    if os.path.isdir(path):
        shutil.rmtree(path, onerror=onerror)


def pick_file():
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(title="Выберите видео для AnyTube",
                                          filetypes=[("Видео", VIDEO_TYPES), ("Все файлы", "*.*")])
        root.destroy()
        return path
    except Exception:
        return ask("Путь к видеофайлу (можно перетащить файл в это окно)")


def repo_exists(name):
    st, _, _ = gh("GET", f"/repos/{CFG['login']}/{name}")
    return st == 200


def free_repo_name(name):
    if not repo_exists(name):
        return name
    n = 2
    while repo_exists(f"{name}_{n}"):
        n += 1
    return f"{name}_{n}"


# ─────────────────────────── большие видео и описание ───────────────────────────
YEAR_SECONDS = 365 * 24 * 3600          # видео не может длиться больше 1 года
DESC_LIMIT = 1_000_000_000               # лимит описания — 1 000 000 000 символов
DESC_CHUNK = 10_000_000                  # описание хранится файлами по 10 млн символов (< 40 МБ)
VOLUME_BUDGET = 900 * MB                 # обычных файлов в одном репозитории-томе (GitHub: push до 2 ГБ)
LFS_PER_VOLUME = 2                       # частей LFS в одном томе
MAX_PARTS = 9999


def fmt_duration(sec):
    sec = int(sec)
    d, sec = divmod(sec, 86400)
    h, sec = divmod(sec, 3600)
    m, s = divmod(sec, 60)
    return (f"{d} дн. " if d else "") + f"{h:02d}:{m:02d}:{s:02d}"


def split_video(src, limit, out_dir, base, ext, allow_reencode=True):
    """Режет видео на пронумерованные части ≤ limit без перекодирования (по ключевым кадрам)."""
    dur = probe_duration(src)
    size = os.path.getsize(src)
    seg = max(2.0, dur * limit * 0.85 / size)
    fmt = "webm" if ext == ".webm" else "mp4"
    for attempt in range(5):
        rmtree(out_dir)
        os.makedirs(out_dir)
        if dur / seg > MAX_PARTS:
            raise Stop(f"Получилось бы больше {MAX_PARTS} частей — выберите вариант с Git LFS (части по 1.9 ГБ).")
        say(f"  Режу на части по ~{seg:.0f} с (≤ {human(limit)} каждая)…")
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", src,
               "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", "-f", "segment",
               "-segment_time", f"{seg:.3f}", "-segment_start_number", "1",
               "-reset_timestamps", "1", "-avoid_negative_ts", "make_zero", "-segment_format", fmt]
        if fmt == "mp4":
            cmd += ["-segment_format_options", "movflags=+faststart"]
        run(cmd + [os.path.join(out_dir, f"{base}.part%04d{ext}")])
        parts = sorted(os.path.join(out_dir, f) for f in os.listdir(out_dir))
        biggest = max(os.path.getsize(p) for p in parts)
        if biggest <= limit:
            say(f"  Готово: {len(parts)} частей")
            return parts
        seg = seg * limit / biggest * 0.85
        if seg < 2:
            break
    if not allow_reencode:
        raise Stop("Не получилось нарезать видео на части нужного размера")
    # ключевые кадры слишком редкие — перекодируем с ключевым кадром каждые 2 секунды
    say("  В видео слишком редкие ключевые кадры — перекодирую, чтобы его можно было нарезать…")
    fixed = os.path.join(os.path.dirname(out_dir), "keyframes.mp4")
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-stats", "-y", "-i", src,
         "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
         "-force_key_frames", "expr:gte(t,n_forced*2)", "-c:a", "aac", "-b:a", "160k",
         "-pix_fmt", "yuv420p", fixed])
    try:
        return split_video(fixed, limit, out_dir, base, ".mp4", allow_reencode=False)
    finally:
        pass  # fixed удалится вместе с рабочей папкой


def read_description():
    """Возвращает (путь_к_txt_или_None, текст_или_None)."""
    say("\nОписание видео (до 1 000 000 000 символов):")
    say("  Enter — без описания")
    say("  1 — написать текст здесь")
    say("  2 — взять из .txt файла (для длинных описаний)")
    c = ask("Выбор", "")
    if c == "1":
        say("Пишите описание. Чтобы закончить — строка из одной точки «.»")
        lines = []
        while True:
            try:
                line = input()
            except EOFError:
                break
            if line.strip() == ".":
                break
            lines.append(line)
        text = "\n".join(lines).strip()
        return None, (text or None)
    if c == "2":
        try:
            import tkinter
            from tkinter import filedialog
            root = tkinter.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            p = filedialog.askopenfilename(title="Файл с описанием", filetypes=[("Текст", "*.txt *.md"), ("Все", "*.*")])
            root.destroy()
        except Exception:
            p = ask("Путь к .txt файлу")
        p = (p or "").strip().strip('"')
        if not p or not os.path.isfile(p):
            raise Stop("Файл описания не найден")
        return p, None
    return None, None


def write_description_chunks(desc_file, desc_text, out_dir):
    """Делит описание на пронумерованные файлы description.part0001.txt… Возвращает (список, всего_символов)."""
    os.makedirs(out_dir, exist_ok=True)
    chunks, total = [], 0

    def emit(piece):
        nonlocal total
        total += len(piece)
        if total > DESC_LIMIT:
            raise Stop(f"Описание длиннее {DESC_LIMIT:,} символов — сократите его.".replace(",", " "))
        name = f"description.part{len(chunks) + 1:04d}.txt"
        p = os.path.join(out_dir, name)
        with open(p, "w", encoding="utf-8", newline="") as f:
            f.write(piece)
        chunks.append({"local": p, "path": name, "chars": len(piece), "bytes": os.path.getsize(p)})

    if desc_text:
        for i in range(0, len(desc_text), DESC_CHUNK):
            emit(desc_text[i:i + DESC_CHUNK])
    elif desc_file:
        say("  Читаю описание…")
        with open(desc_file, encoding="utf-8-sig", errors="replace", newline="") as f:
            while True:
                piece = f.read(DESC_CHUNK)
                if not piece:
                    break
                emit(piece)
    return chunks, total


def pack_volumes(items):
    """Раскладывает файлы по репозиториям-томам: ≤ VOLUME_BUDGET обычных байт и ≤ LFS_PER_VOLUME частей LFS."""
    vols, cur, plain, lfs = [], [], 0, 0
    for it in items:
        w_plain = 0 if it.get("lfs") else it["size"]
        w_lfs = 1 if it.get("lfs") else 0
        if cur and (plain + w_plain > VOLUME_BUDGET or lfs + w_lfs > LFS_PER_VOLUME):
            vols.append(cur)
            cur, plain, lfs = [], 0, 0
        cur.append(it)
        plain += w_plain
        lfs += w_lfs
    if cur:
        vols.append(cur)
    return vols


def push_repo(work, repo, description, files, lfs_files, topics, login):
    """Создаёт публичный репозиторий и отправляет туда файлы из папки work."""
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": description[:300], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий {repo}: {gh_error(st, j)}")
    if topics:
        gh("PUT", f"/repos/{login}/{repo}/topics", {"names": topics})
    auth = base64.b64encode(f"{login}:{CFG['token']}".encode()).decode()
    git = lambda *a: run(["git", *a], cwd=work)
    git("init", "-q")
    git("checkout", "-q", "-b", "main")
    git("config", "user.name", login)
    git("config", "user.email", f"{CFG['user_id']}+{login}@users.noreply.github.com")
    git("config", "credential.helper", "")
    git("config", "http.https://github.com/.extraheader", f"AUTHORIZATION: basic {auth}")
    git("config", "http.postBuffer", "524288000")
    git("config", "lfs.locksverify", "false")
    if lfs_files:
        git("lfs", "install", "--local")
        for f in lfs_files:
            git("lfs", "track", f)
    git("add", "-A")
    git("commit", "-q", "-m", f"AnyTube: {description[:60]}")
    git("remote", "add", "origin", f"https://github.com/{login}/{repo}.git")
    git("push", "-u", "origin", "main")


# ─────────────────────────── загрузка видео ───────────────────────────
def upload_video(path=None):
    ensure_token()
    site = ensure_site()
    path = (path or pick_file() or "").strip().strip('"')
    if not path or not os.path.isfile(path):
        raise Stop("Файл не выбран или не найден")
    stem, ext = os.path.splitext(os.path.basename(path))
    ext = ext.lower()
    size = os.path.getsize(path)
    say(f"\nФайл: {path}  ({human(size)})")

    ensure_ffmpeg()
    duration = probe_duration(path)
    say(f"Длительность: {fmt_duration(duration)}")
    if duration > YEAR_SECONDS:
        raise Stop("Видео длиннее 1 года — такие AnyTube не принимает.")

    title = ask("Название видео (заголовок на сайте)", stem)
    base = slug(ask("Короткое имя для ссылки (латиница)", slug(stem)))[:70]
    main_repo = free_repo_name(VIDEO_PREFIX + base)
    desc_file, desc_text = read_description()

    needs_convert = ext not in WEB_EXT
    out_ext = ext if not needs_convert else ".mp4"
    mode = "plain"
    if needs_convert:
        say(f"Формат {ext} плохо играет в браузерах — сконвертирую в MP4.")
    if size > PLAIN_LIMIT or needs_convert:
        say("\nКак загрузить?")
        say("  1 — Разбить на части по ~95 МБ — полное качество, без квоты Git LFS, любой размер  [рекомендуется]")
        say("  2 — Git LFS: части до 1.9 ГБ (меньше частей, но тратит квоту LFS)")
        say("  3 — Сжать в один файл до 95 МБ (качество ниже)")
        mode = {"2": "lfs", "3": "compress"}.get(ask("Ваш выбор", "1"), "plain")

    work = os.path.join(TOOLS, "work", main_repo)
    rmtree(work)
    os.makedirs(work)
    login = CFG["login"]
    try:
        # 1. Видео → список частей
        src = path
        if mode == "compress":
            dst = os.path.join(work, base + ".mp4")
            transcode(path, dst, PLAIN_LIMIT)
            parts, out_ext = [dst], ".mp4"
        else:
            if needs_convert:
                src = os.path.join(work, "converted.mp4")
                transcode(path, src)
            limit = LFS_LIMIT if mode == "lfs" else PLAIN_LIMIT
            if os.path.getsize(src) <= limit:
                one = os.path.join(work, base + out_ext)
                if out_ext == ".mp4":
                    faststart(src, one)
                else:
                    place_file(src, one)
                parts = [one]
            else:
                say(f"Видео {human(os.path.getsize(src))} — делю на пронумерованные части.")
                parts = split_video(src, limit, os.path.join(work, "parts"), base, out_ext)
            if src != path and os.path.exists(src) and len(parts) > 1:
                os.remove(src)  # освобождаем место

        items = []
        for i, p in enumerate(parts, 1):
            psize = os.path.getsize(p)
            items.append({"kind": "part", "local": p, "path": os.path.basename(p), "size": psize,
                          "lfs": psize > PLAIN_LIMIT, "num": i,
                          "duration": round(probe_duration(p), 3) if len(parts) > 1 else round(duration, 3)})
        total_dur = sum(it["duration"] for it in items)
        if total_dur > YEAR_SECONDS:
            raise Stop("После обработки видео длиннее 1 года — не загружаю.")

        # 2. Описание → пронумерованные куски
        chunks, desc_chars = write_description_chunks(desc_file, desc_text, os.path.join(work, "desc"))
        for c in chunks:
            items.append({"kind": "desc", "local": c["local"], "path": c["path"], "size": c["bytes"],
                          "chars": c["chars"], "lfs": False})
        if desc_chars:
            say(f"Описание: {desc_chars:,} символов, файлов: {len(chunks)}".replace(",", " "))

        # 3. Раскладка по репозиториям-томам
        vols = pack_volumes(items)
        names = [main_repo] + [f"{main_repo}_vol{k}" for k in range(2, len(vols) + 1)]
        for n in names[1:]:
            if repo_exists(n):
                raise Stop(f"Репозиторий {n} уже существует — выберите другое короткое имя.")
        for k, vol in enumerate(vols):
            for it in vol:
                it["repo"] = names[k]
        if len(vols) > 1:
            say(f"Видео займёт {len(vols)} репозитория(ев): {names[0]} … {names[-1]}")

        virtual = base + out_ext
        watch = f"{site}/watch?v={urllib.parse.quote(f'{login}/{main_repo}/{virtual}', safe='')}" if site else ""
        manifest = {
            "anytube": 1, "title": title, "file": virtual, "duration": round(total_dur, 3),
            "parts": [{k: it[k] for k in ("repo", "path", "size", "duration", "lfs")} for it in items if it["kind"] == "part"],
            "description": {"chars": desc_chars,
                            "chunks": [{k: it[k] for k in ("repo", "path", "chars", "size")} for it in items if it["kind"] == "desc"]},
        }

        # 4. Отправка: сначала тома, главный репозиторий последним (чтобы сайт не увидел неполное видео)
        order = list(range(1, len(vols))) + [0]
        for step, k in enumerate(order, 1):
            vdir = os.path.join(work, f"vol{k + 1}")
            os.makedirs(vdir)
            for it in vols[k]:
                os.replace(it["local"], os.path.join(vdir, it["path"])) if it["local"] != path \
                    else place_file(it["local"], os.path.join(vdir, it["path"]))
            if k == 0:
                with open(os.path.join(vdir, "anytube.json"), "w", encoding="utf-8") as f:
                    json.dump(manifest, f, ensure_ascii=False, indent=1)
                with open(os.path.join(vdir, "README.md"), "w", encoding="utf-8") as f:
                    f.write(f"# {title}\n\nВидео для AnyTube, длительность {fmt_duration(total_dur)}, "
                            f"частей: {len(manifest['parts'])}.\n" + (f"\nСмотреть: {watch}\n" if watch else ""))
                topics, rdesc = ["anytubevideo"], title
            else:
                with open(os.path.join(vdir, "anytube-volume.json"), "w", encoding="utf-8") as f:
                    json.dump({"main": f"{login}/{main_repo}", "volume": k + 1}, f)
                topics, rdesc = [], f"{title} — том {k + 1} (AnyTube)"
            say(f"\n[{step}/{len(vols)}] Загружаю {names[k]}…")
            push_repo(vdir, names[k], rdesc, [it["path"] for it in vols[k]],
                      [it["path"] for it in vols[k] if it["lfs"]], topics, login)
            rmtree(vdir)
    finally:
        rmtree(work)  # удаляет копии видео и токен из настроек временных репозиториев

    say("\n✅ Видео загружено!")
    say(f"   Репозиторий: https://github.com/{login}/{main_repo}")
    if len(manifest["parts"]) > 1:
        say(f"   Частей: {len(manifest['parts'])} — на сайте они играют подряд как одно видео.")
    if watch:
        say(f"   На AnyTube:  {watch}")
    say("   На сайте появится в течение ~10 минут (поиск GitHub иногда дольше).")


# ─────────────────────────── комментарии ───────────────────────────
def parse_video_ref(ref):
    """Принимает ссылку AnyTube (…/watch?v=…), id 'автор/репо/файл.mp4' или 'автор/файл.mp4'."""
    ref = ref.strip().strip('"')
    if "v=" in ref:
        ref = urllib.parse.parse_qs(urllib.parse.urlparse(ref).query).get("v", [""])[0]
    ref = urllib.parse.unquote(ref).strip("/")
    parts = [p for p in ref.split("/") if p]
    if len(parts) < 2:
        raise Stop("Не понял, к какому видео комментарий. Вставьте ссылку со страницы видео на AnyTube.")
    return parts[0], parts[-1]


def comment_stem(author, file_name):
    head = f"{COMMENT_PREFIX}{author}_"
    tail = "_Comment."
    file_part = safe_file_part(file_name)[: 100 - len(head) - len(tail) - 4]
    return f"{head}{file_part}{tail}"


def next_comment_number(stem):
    nums = [0]
    page = 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список ваших репозиториев: {gh_error(st, j)}")
        for r in j:
            if r["name"].lower().startswith(stem.lower()):
                tail = r["name"][len(stem):]
                if tail.isdigit():
                    nums.append(int(tail))
        if len(j) < 100:
            return max(nums) + 1
        page += 1


def post_comment():
    ensure_token()
    author, file_name = parse_video_ref(ask("Ссылка на видео AnyTube (или автор/репозиторий/файл.mp4)"))
    say(f"Комментарий к видео {file_name} автора {author}.")
    say("Напишите комментарий. Чтобы закончить — пустая строка.")
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if not line.strip():
            break
        lines.append(line)
    text = "\n".join(lines).strip()
    if not text:
        raise Stop("Пустой комментарий не отправлен")

    login = CFG["login"]
    stem = comment_stem(author, file_name)
    num = next_comment_number(stem)
    repo = f"{stem}{num}"
    say(f"Создаю {login}/{repo}…")
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": " ".join(text.split())[:300], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
    gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubecomment"]})
    body = f"---\nvideo_author: {author}\nvideo_file: {file_name}\n---\n\n{text}\n"
    st, j, _ = gh("PUT", f"/repos/{login}/{repo}/contents/comment.md", {
        "message": "AnyTube comment", "content": base64.b64encode(body.encode()).decode(),
    })
    if st not in (200, 201):
        say(f"⚠ Полный текст не сохранился ({gh_error(st, j)}), но короткая версия есть в описании.")
    say(f"\n✅ Комментарий №{num} опубликован: https://github.com/{login}/{repo}")
    say("   На сайте появится в течение ~10 минут. Удалить — удалите этот репозиторий.")


# ─────────────────────────── дизлайки ───────────────────────────
# Дизлайк = репозиторий:  ваш_ник/anytubecomment_<автор>_<файл>_Commet.<уровень 1–5>.diske
# От одного человека к одному видео считается один дизлайк; повторный — меняет уровень.
DISLIKE_LEVELS = {
    1: "😕 Ну не очень",
    2: "😒 Так себе",
    3: "👎 Плохо",
    4: "😖 Очень плохо, зря потратил время",
    5: "🤮 Это убогий видос, мой день испорчен",
}
DISLIKE_RE = re.compile(r"_(?:Comment|Commet|Coment)\.([0-5])\.(?:diske|dislike|dizlike)$", re.I)


def dislike_stem(author, file_name):
    head = f"{COMMENT_PREFIX}{author}_"
    tail = "_Commet."
    file_part = safe_file_part(file_name)[: 100 - len(head) - len(tail) - len("5.diske")]
    return f"{head}{file_part}{tail}"


def my_dislikes(author, file_name):
    """Ваши уже поставленные дизлайки к этому видео (обычно 0 или 1)."""
    head = f"{COMMENT_PREFIX}{author}_{safe_file_part(file_name)}".lower()
    short = dislike_stem(author, file_name)[:-len("_Commet.")].lower()  # имя могло быть обрезано
    found, page = [], 1
    while True:
        st, j, _ = gh("GET", f"/user/repos?affiliation=owner&per_page=100&page={page}")
        if st != 200:
            raise Stop(f"Не удалось получить список ваших репозиториев: {gh_error(st, j)}")
        for r in j:
            m = DISLIKE_RE.search(r["name"])
            if m and r["name"][:m.start()].lower() in (head, short):
                found.append((r["name"], int(m.group(1))))
        if len(j) < 100:
            return found
        page += 1


def post_dislike():
    ensure_token()
    author, file_name = parse_video_ref(ask("Ссылка на видео AnyTube (или автор/репозиторий/файл.mp4)"))
    login = CFG["login"]
    if author.lower() == login.lower():
        raise Stop("Своему видео дизлайк поставить нельзя")
    existing = my_dislikes(author, file_name)
    say(f"\nДизлайк видео {file_name} автора {author}.")
    if existing:
        say(f"Сейчас у вас стоит: {DISLIKE_LEVELS.get(existing[0][1], existing[0][1])}")
    for lvl, label in DISLIKE_LEVELS.items():
        say(f"  {lvl} — {label}")
    if existing:
        say("  0 — убрать дизлайк")
    c = ask("Уровень дизлайка", "")
    if not c.isdigit() or int(c) not in DISLIKE_LEVELS and not (existing and c == "0"):
        raise Stop("Нужно число от 1 до 5")
    level = int(c)

    if existing:
        old, _ = existing[0]
        if level == 0:
            st, j, _ = gh("DELETE", f"/repos/{login}/{old}")
            if st == 204:
                say("✅ Дизлайк убран.")
            else:
                say("Токену не хватает права удалять репозитории (delete_repo).")
                say(f"Удалите репозиторий вручную: https://github.com/{login}/{old}/settings  (внизу «Delete this repository»)")
            return
        new = f"{dislike_stem(author, file_name)}{level}.diske"
        if new != old:
            st, j, _ = gh("PATCH", f"/repos/{login}/{old}", {"name": new, "description": DISLIKE_LEVELS[level]})
            if st != 200:
                raise Stop(f"GitHub не переименовал репозиторий: {gh_error(st, j)}")
        say(f"\n✅ Дизлайк изменён: {DISLIKE_LEVELS[level]}")
        say(f"   https://github.com/{login}/{new}")
        return

    repo = f"{dislike_stem(author, file_name)}{level}.diske"
    say(f"Создаю {login}/{repo}…")
    st, j, _ = gh("POST", "/user/repos", {
        "name": repo, "description": DISLIKE_LEVELS[level], "private": False,
        "has_issues": False, "has_wiki": False, "has_projects": False,
    })
    if st != 201:
        raise Stop(f"GitHub не создал репозиторий: {gh_error(st, j)}")
    gh("PUT", f"/repos/{login}/{repo}/topics", {"names": ["anytubedislike"]})
    say(f"\n✅ Дизлайк поставлен: {DISLIKE_LEVELS[level]}")
    say(f"   https://github.com/{login}/{repo}")
    say("   На сайте появится в течение ~10 минут. Изменить уровень — снова выберите «Дизлайк».")


# ─────────────────────────── меню ───────────────────────────
def main():
    say("═══════════ AnyTube Uploader ═══════════")
    args = [a for a in sys.argv[1:] if a.strip()]
    if args:  # видео перетащили на AnyTube.cmd
        for p in args:
            try:
                upload_video(p)
            except Stop as e:
                say(f"\n❌ {e}")
        return
    while True:
        say(f"\n{'Аккаунт: ' + CFG['login'] if CFG.get('login') else 'Аккаунт: не подключён'}")
        say("  1 — Загрузить видео")
        say("  2 — Написать комментарий к видео")
        say("  3 — Поставить дизлайк (5 уровней)")
        say("  4 — Сменить токен GitHub")
        say("  5 — Сменить адрес сайта")
        say("  0 — Выход")
        c = ask("Выбор", "1")
        try:
            if c == "1":
                upload_video()
            elif c == "2":
                post_comment()
            elif c == "3":
                post_dislike()
            elif c == "4":
                ensure_token(force=True)
                say(f"Подключён аккаунт {CFG['login']}")
            elif c == "5":
                CFG.pop("site", None)
                ensure_site()
            elif c == "0":
                return
        except Stop as e:
            say(f"\n❌ {e}")
        except KeyboardInterrupt:
            say("\nОтменено.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
