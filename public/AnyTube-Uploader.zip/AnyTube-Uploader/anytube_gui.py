#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AnyTube Uploader — окно. Вся работа делается функциями из anytube_uploader.py."""
import builtins
import os
import queue
import subprocess
import sys
import threading
import traceback
import webbrowser

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import anytube_uploader as core

APP_DIR = os.path.dirname(os.path.abspath(__file__))
RED, DARK, PANEL, TEXT, MUTED, GREEN = "#e8161d", "#15151a", "#1f1f26", "#f1f1f4", "#9a9aa8", "#2ea05a"

# ── без консоли: дочерние git/ffmpeg не открывают чёрные окна, вопросы в консоль не задаются ──
if os.name == "nt":
    _Popen = subprocess.Popen

    class _QuietPopen(_Popen):
        def __init__(self, *a, **kw):
            # Git for Windows (MSYS) может падать с 0xC0000005, если запустить его вообще без консоли
            # (CREATE_NO_WINDOW). Поэтому даём ему настоящую, но СКРЫТУЮ консоль.
            if not kw.get("creationflags"):
                kw["creationflags"] = 0x00000010  # CREATE_NEW_CONSOLE
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = 0  # SW_HIDE
                kw.setdefault("startupinfo", si)
            kw.setdefault("stdin", subprocess.DEVNULL)
            if kw.get("stdout") is None:
                kw["stdout"] = subprocess.DEVNULL
            if kw.get("stderr") is None:
                kw["stderr"] = subprocess.DEVNULL
            super().__init__(*a, **kw)
    subprocess.Popen = _QuietPopen

core.CAPTURE_ALL = True  # вывод git/ffmpeg собирается, при ошибке показывается в журнале


def _no_input(*_a, **_k):
    raise EOFError  # в окне вопросов в консоль нет — все данные берутся из полей


builtins.input = _no_input


class _Log:
    """Перехват print() из ядра → очередь → окно лога."""
    def __init__(self, q):
        self.q = q

    def write(self, s):
        if s:
            self.q.put(s)

    def flush(self):
        pass


class App(tk.Tk):
    def __init__(self, preset=None):
        super().__init__()
        self.title("AnyTube Uploader")
        self.geometry("1220x860")
        self.minsize(1000, 700)
        self.configure(bg=DARK)
        try:
            self.iconbitmap(os.path.join(APP_DIR, "anytube.ico"))
        except Exception:
            try:
                self.iconphoto(True, tk.PhotoImage(file=os.path.join(APP_DIR, "icon256.png")))
            except Exception:
                pass
        self.q = queue.Queue()
        sys.stdout = sys.stderr = _Log(self.q)
        self.busy = False
        self._style()
        self._header()
        body = tk.Frame(self, bg=DARK)
        body.pack(fill="both", expand=True, padx=12, pady=(0, 10))
        self.body = body
        nb = ttk.Notebook(body)
        nb.pack(side="left", fill="both", expand=True)
        self.nb = nb
        self._tab_upload(nb)
        self._tab_desc(nb)
        self._tab_comment(nb)
        self._tab_dislike(nb)
        self._tab_settings(nb)
        self._log_area()
        self._clipboard_keys()
        self.after(100, self._pump)
        if preset:
            self.v_path.set(preset)
            self._on_file()
        if not core.CFG.get("token"):
            self.nb.select(self.tab_settings)
            self.say("👋 Сначала вставьте токен GitHub во вкладке «Настройки».\n")
        else:
            self.say(f"Аккаунт: {core.CFG.get('login', '?')}. Готово к загрузке.\n")

    # ── оформление ──
    # ── буфер обмена: Ctrl+V/C/X/A на ЛЮБОЙ раскладке + меню по правой кнопке ──
    # На русской раскладке tkinter получает «м/с/ч/ф» вместо «v/c/x/a» и сам сочетания не узнаёт.
    _KEYS = {  # keysym (рус./англ.) и коды клавиш Windows → действие
        "v": "<<Paste>>", "cyrillic_em": "<<Paste>>", 86: "<<Paste>>",
        "c": "<<Copy>>", "cyrillic_es": "<<Copy>>", 67: "<<Copy>>",
        "x": "<<Cut>>", "cyrillic_che": "<<Cut>>", 88: "<<Cut>>",
        "a": "all", "cyrillic_ef": "all", 65: "all",
        "z": "<<Undo>>", "cyrillic_ya": "<<Undo>>", 90: "<<Undo>>",
    }

    def _clipboard_keys(self):
        for cls in ("TEntry", "Entry", "Text", "TCombobox"):
            self.bind_class(cls, "<Control-KeyPress>", self._ctrl_key, add="+")
            self.bind_class(cls, "<Button-3>", self._context_menu, add="+")
        self._menu = tk.Menu(self, tearoff=0, bg=PANEL, fg=TEXT, activebackground=RED, activeforeground="white")
        for label, ev in (("Вставить", "<<Paste>>"), ("Копировать", "<<Copy>>"), ("Вырезать", "<<Cut>>")):
            self._menu.add_command(label=label, command=lambda e=ev: self._menu_target.event_generate(e))
        self._menu.add_separator()
        self._menu.add_command(label="Выделить всё", command=lambda: self._select_all(self._menu_target))
        self._menu_target = None

    def _ctrl_key(self, e):
        ks = (e.keysym or "").lower()
        if ks in ("v", "c", "x", "z") and e.keysym.isascii():
            return None  # латиница — tkinter справится сам, не дублируем вставку
        action = self._KEYS.get(ks) or (self._KEYS.get(e.keycode) if os.name == "nt" else None)
        if not action:
            return None
        if action == "all":
            self._select_all(e.widget)
        else:
            e.widget.event_generate(action)
        return "break"

    @staticmethod
    def _select_all(w):
        try:
            if isinstance(w, tk.Text):
                w.tag_add("sel", "1.0", "end-1c")
                w.mark_set("insert", "end-1c")
            else:
                w.select_range(0, "end")
                w.icursor("end")
        except tk.TclError:
            pass

    def _context_menu(self, e):
        self._menu_target = e.widget
        try:
            e.widget.focus_set()
            self._menu.tk_popup(e.x_root, e.y_root)
        finally:
            self._menu.grab_release()

    def _style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure(".", background=DARK, foreground=TEXT, fieldbackground=PANEL, font=("Segoe UI", 10))
        st.configure("TNotebook", background=DARK, borderwidth=0)
        st.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(14, 7), font=("Segoe UI", 10, "bold"))
        st.map("TNotebook.Tab", background=[("selected", RED)], foreground=[("selected", "white")])
        st.configure("TFrame", background=DARK)
        st.configure("Card.TFrame", background=PANEL)
        st.configure("TLabel", background=DARK, foreground=TEXT)
        st.configure("Card.TLabel", background=PANEL, foreground=TEXT)
        st.configure("Muted.TLabel", background=DARK, foreground=MUTED, font=("Segoe UI", 9))
        st.configure("CardMuted.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 9))
        st.configure("H.TLabel", background=PANEL, foreground=TEXT, font=("Segoe UI", 11, "bold"))
        st.configure("TCheckbutton", background=DARK, foreground=TEXT, font=("Segoe UI", 10, "bold"))
        st.map("TCheckbutton", background=[("active", DARK)])
        st.configure("Card.TRadiobutton", background=PANEL, foreground=TEXT)
        st.map("Card.TRadiobutton", background=[("active", PANEL)])
        st.configure("TEntry", fieldbackground="#2a2a33", foreground=TEXT, insertcolor=TEXT)
        st.configure("TCombobox", fieldbackground="#2a2a33", foreground=TEXT, background=PANEL, arrowcolor=TEXT)
        st.map("TCombobox", fieldbackground=[("readonly", "#2a2a33")], foreground=[("readonly", TEXT)],
               selectbackground=[("readonly", "#2a2a33")], selectforeground=[("readonly", TEXT)])
        self.option_add("*TCombobox*Listbox.background", "#2a2a33")
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        st.configure("Accent.TButton", background=RED, foreground="white", font=("Segoe UI", 11, "bold"), padding=(18, 9), borderwidth=0)
        st.map("Accent.TButton", background=[("active", "#ff3b42"), ("disabled", "#5a2a2c")])
        st.configure("TButton", background="#2a2a33", foreground=TEXT, padding=(10, 5), borderwidth=0)
        st.map("TButton", background=[("active", "#3a3a45")])
        st.configure("red.Horizontal.TProgressbar", background=RED, troughcolor=PANEL, borderwidth=0)

    def _header(self):
        h = tk.Frame(self, bg=DARK)
        h.pack(fill="x", padx=14, pady=(10, 8))
        try:
            self._logo = tk.PhotoImage(file=os.path.join(APP_DIR, "icon256.png")).subsample(6, 6)
            tk.Label(h, image=self._logo, bg=DARK).pack(side="left")
        except Exception:
            pass
        tk.Label(h, text=" AnyTube", fg=TEXT, bg=DARK, font=("Segoe UI", 20, "bold")).pack(side="left")
        tk.Label(h, text="Uploader", fg="white", bg=RED, font=("Segoe UI", 12, "bold"), padx=8).pack(side="left", padx=8)
        self.lbl_acc = tk.Label(h, text="", fg=MUTED, bg=DARK, font=("Segoe UI", 10))
        self.lbl_acc.pack(side="right")
        self._acc()

    def _acc(self):
        self.lbl_acc.config(text=f"👤 {core.CFG['login']}" if core.CFG.get("login") else "аккаунт не подключён")

    # ── вспомогательное ──
    def card(self, parent, title=None):
        f = ttk.Frame(parent, style="Card.TFrame", padding=10)
        f.pack(fill="x", pady=5)
        if title:
            ttk.Label(f, text=title, style="H.TLabel").grid(row=0, column=0, columnspan=6, sticky="w", pady=(0, 6))
        return f

    def row(self, parent, r, label, var, width=40, browse=None, hint=None):
        ttk.Label(parent, text=label, style="Card.TLabel").grid(row=r, column=0, sticky="w", padx=(0, 8), pady=3)
        e = ttk.Entry(parent, textvariable=var, width=width)
        e.grid(row=r, column=1, sticky="we", pady=3)
        parent.columnconfigure(1, weight=1)
        if browse:
            ttk.Button(parent, text="Выбрать…", command=browse).grid(row=r, column=2, padx=(6, 0))
        if hint:
            ttk.Label(parent, text=hint, style="CardMuted.TLabel").grid(row=r, column=3, sticky="w", padx=6)
        return e

    def text(self, parent, h=5):
        t = tk.Text(parent, height=h, bg="#2a2a33", fg=TEXT, insertbackground=TEXT, relief="flat", wrap="word", font=("Segoe UI", 10))
        return t

    # ── вкладка «Загрузить» ──
    def _tab_upload(self, nb):
        f = ttk.Frame(nb, padding=8)
        nb.add(f, text="⬆  Загрузить")
        self.v_path, self.v_title, self.v_base = tk.StringVar(), tk.StringVar(), tk.StringVar()
        c = self.card(f, "Видео")
        self.row(c, 1, "Видеофайл", self.v_path, browse=self._pick_video)
        self.row(c, 2, "Название", self.v_title)
        self.row(c, 3, "Имя для ссылки", self.v_base, hint="латиница")
        self.v_mode = tk.StringVar(value="Части по 95 МБ — полное качество (рекомендуется)")
        ttk.Label(c, text="Большое видео", style="Card.TLabel").grid(row=4, column=0, sticky="w")
        ttk.Combobox(c, textvariable=self.v_mode, state="readonly", width=48, values=[
            "Части по 95 МБ — полное качество (рекомендуется)", "Git LFS — части до 1,9 ГБ", "Сжать в один файл 95 МБ"]).grid(row=4, column=1, sticky="w", pady=3)

        g = ttk.Frame(f)
        g.pack(fill="x", pady=(6, 2))
        self.v_app, self.v_wall = tk.BooleanVar(), tk.BooleanVar()
        ttk.Checkbutton(g, text="📦  Мы рекламируем приложение (продажа или подписка)", variable=self.v_app,
                        command=lambda: self._kind("app")).pack(anchor="w")
        ttk.Checkbutton(g, text="🖼  Это анимированные обои (бесплатно или платно)", variable=self.v_wall,
                        command=lambda: self._kind("wallpaper")).pack(anchor="w", pady=(2, 0))

        self.money = self.card(f, "💰 Монетизация")
        self.v_paid = tk.StringVar(value="free")
        self.v_hour, self.v_buy, self.v_trailer = tk.StringVar(), tk.StringVar(), tk.StringVar(value="60")
        self.v_app_path = tk.StringVar()
        self.v_sub = {p: tk.StringVar() for p in core.SUB_PERIODS}
        self._money()

        d = self.card(f, "📝 Описание (до 1 000 000 000 символов)")
        self.t_desc = self.text(d, 4)
        self.t_desc.grid(row=1, column=0, columnspan=4, sticky="we")
        d.columnconfigure(0, weight=1)
        self.v_desc_file = tk.StringVar()
        ttk.Button(d, text="Взять из .txt файла…", command=lambda: self._pick_txt(self.v_desc_file)).grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Label(d, textvariable=self.v_desc_file, style="CardMuted.TLabel").grid(row=2, column=1, sticky="w", pady=(6, 0))

        self.btn_up = ttk.Button(f, text="⬆  Загрузить на AnyTube", style="Accent.TButton", command=self._do_upload)
        self.btn_up.pack(pady=(8, 2))

    def _kind(self, which):
        if which == "app" and self.v_app.get():
            self.v_wall.set(False)
        if which == "wallpaper" and self.v_wall.get():
            self.v_app.set(False)
        self._money()

    def kind(self):
        return "app" if self.v_app.get() else "wallpaper" if self.v_wall.get() else "video"

    def _money(self):
        c = self.money
        for w in c.grid_slaves():
            if int(w.grid_info()["row"]) > 0:
                w.destroy()
        k = self.kind()
        r = 1
        if k == "app":
            self.row(c, r, "Файл приложения", self.v_app_path, browse=self._pick_app)
            r += 1
        rb = ttk.Frame(c, style="Card.TFrame")
        rb.grid(row=r, column=0, columnspan=4, sticky="w", pady=3)
        free_txt = {"video": "Бесплатное видео", "app": "Приложение бесплатно", "wallpaper": "Бесплатные обои"}[k]
        paid_txt = {"video": "Платное видео", "app": "Платное приложение", "wallpaper": "Платные обои"}[k]
        ttk.Radiobutton(rb, text=free_txt, value="free", variable=self.v_paid, style="Card.TRadiobutton", command=self._money).pack(side="left")
        ttk.Radiobutton(rb, text=paid_txt, value="paid", variable=self.v_paid, style="Card.TRadiobutton", command=self._money).pack(side="left", padx=14)
        r += 1
        if self.v_paid.get() != "paid":
            hint = {"video": "Видео смотрят бесплатно.", "app": "Приложение скачивают бесплатно, ролик — реклама.",
                    "wallpaper": "Обои скачивают бесплатно."}[k]
            ttk.Label(c, text=hint, style="CardMuted.TLabel").grid(row=r, column=0, columnspan=4, sticky="w")
            return
        if k == "video":
            self.row(c, r, "Цена за час просмотра, ₽", self.v_hour, 12, hint="например 6 — списывается поминутно")
            self.row(c, r + 1, "Покупка навсегда, ₽", self.v_buy, 12, hint="пусто — только почасово")
            self.row(c, r + 2, "Бесплатный трейлер, сек", self.v_trailer, 12, hint="первые секунды видно всем")
        elif k == "app":
            self.row(c, r, "Покупка навсегда, ₽", self.v_buy, 12, hint="пусто — только подписка")
            ttk.Label(c, text="Подписка на скачивание (пусто — такого периода нет):", style="CardMuted.TLabel").grid(row=r + 1, column=0, columnspan=4, sticky="w", pady=(6, 2))
            for i, (p, name) in enumerate(core.SUB_PERIODS.items()):
                self.row(c, r + 2 + i, f"   за {name}, ₽", self.v_sub[p], 12)
        else:
            self.row(c, r, "Цена обоев, ₽", self.v_buy, 12, hint="на сайте будет только превью")
        ttk.Label(c, text="🔒 Платные файлы уйдут в приватный репозиторий, нужен токен с галочкой «repo».",
                  style="CardMuted.TLabel").grid(row=r + 8, column=0, columnspan=4, sticky="w", pady=(6, 0))

    # ── вкладки описания / комментария / дизлайка ──
    def _tab_desc(self, nb):
        f = ttk.Frame(nb, padding=8)
        nb.add(f, text="📝  Описание")
        c = self.card(f, "Добавить или изменить описание у своего видео")
        self.v_d_ref = tk.StringVar()
        self.row(c, 1, "Ссылка на видео", self.v_d_ref, hint="AnyTube или GitHub")
        self.t_d = self.text(c, 10)
        self.t_d.grid(row=2, column=0, columnspan=4, sticky="we", pady=6)
        self.v_d_file = tk.StringVar()
        ttk.Button(c, text="Взять из .txt файла…", command=lambda: self._pick_txt(self.v_d_file)).grid(row=3, column=0, sticky="w")
        ttk.Label(c, textvariable=self.v_d_file, style="CardMuted.TLabel").grid(row=3, column=1, sticky="w")
        ttk.Button(f, text="Сохранить описание", style="Accent.TButton", command=self._do_desc).pack(pady=8)

    def _tab_comment(self, nb):
        f = ttk.Frame(nb, padding=8)
        nb.add(f, text="💬  Комментарий")
        c = self.card(f, "Комментарий к видео")
        self.v_c_ref = tk.StringVar()
        self.row(c, 1, "Ссылка на видео", self.v_c_ref)
        self.t_c = self.text(c, 8)
        self.t_c.grid(row=2, column=0, columnspan=4, sticky="we", pady=6)
        ttk.Button(f, text="Опубликовать комментарий", style="Accent.TButton", command=self._do_comment).pack(pady=8)

    def _tab_dislike(self, nb):
        f = ttk.Frame(nb, padding=8)
        nb.add(f, text="👎  Дизлайк")
        c = self.card(f, "Дизлайк видео — 5 уровней")
        self.v_l_ref = tk.StringVar()
        self.row(c, 1, "Ссылка на видео", self.v_l_ref)
        self.v_level = tk.IntVar(value=1)
        for i, (lvl, name) in enumerate(core.DISLIKE_LEVELS.items()):
            ttk.Radiobutton(c, text=f"{lvl} — {name}", value=lvl, variable=self.v_level, style="Card.TRadiobutton").grid(row=2 + i, column=0, columnspan=3, sticky="w")
        ttk.Radiobutton(c, text="0 — убрать мой дизлайк", value=0, variable=self.v_level, style="Card.TRadiobutton").grid(row=8, column=0, columnspan=3, sticky="w")
        ttk.Button(f, text="Поставить дизлайк", style="Accent.TButton", command=self._do_dislike).pack(pady=8)

    def _tab_settings(self, nb):
        f = ttk.Frame(nb, padding=8)
        nb.add(f, text="⚙  Настройки")
        self.tab_settings = f
        c = self.card(f, "Токен GitHub")
        self.v_token = tk.StringVar(value=core.CFG.get("token", ""))
        e = self.row(c, 1, "Токен", self.v_token, 50)
        e.config(show="•")
        ttk.Label(c, text="github.com/settings/tokens/new → Tokens (classic) → галочка «public_repo» (бесплатные видео)\n"
                          "или «repo» (если будете продавать: платные файлы — в приватных репозиториях).",
                  style="CardMuted.TLabel").grid(row=2, column=0, columnspan=4, sticky="w", pady=4)
        b = ttk.Frame(c, style="Card.TFrame")
        b.grid(row=3, column=0, columnspan=4, sticky="w")
        ttk.Button(b, text="Открыть страницу токенов", command=lambda: webbrowser.open("https://github.com/settings/tokens/new?scopes=repo&description=AnyTube%20Uploader")).pack(side="left")
        ttk.Button(b, text="Сохранить и проверить", command=self._do_token).pack(side="left", padx=8)
        c2 = self.card(f, "Сайт")
        self.v_site = tk.StringVar(value=core.CFG.get("site", "https://anytube.onrender.com"))
        self.v_plat = tk.StringVar(value=core.platform_account())
        self.row(c2, 1, "Адрес сайта", self.v_site, 50)
        self.row(c2, 2, "Аккаунт сайта", self.v_plat, 30, hint="получает доступ к платным файлам")
        ttk.Button(c2, text="Сохранить", command=self._save_site).grid(row=3, column=0, sticky="w", pady=(6, 0))
        ttk.Button(c2, text="🔑 Дать сайту доступ к платным файлам", command=lambda: self.run("Доступ к платным файлам", core.reinvite_all)).grid(row=3, column=1, sticky="w", pady=(6, 0), padx=8)
        ttk.Label(f, text="Токен хранится в config.json рядом с программой. Никому не передавайте этот файл.",
                  style="Muted.TLabel").pack(anchor="w", pady=6)

    # ── лог ──
    def _log_area(self):
        f = tk.Frame(self.body, bg=DARK, width=360)
        f.pack(side="right", fill="y", padx=(10, 0))
        f.pack_propagate(False)
        tk.Label(f, text="Журнал", fg=MUTED, bg=DARK, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.pb = ttk.Progressbar(f, mode="indeterminate", style="red.Horizontal.TProgressbar")
        self.pb.pack(fill="x", pady=(0, 4))
        self.log = tk.Text(f, height=9, width=44, bg="#0c0c10", fg="#cfd2da", relief="flat", wrap="word", font=("Consolas", 9), state="disabled")
        sb = ttk.Scrollbar(f, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log.pack(fill="both", expand=True)

    def say(self, s):
        self.q.put(s)

    def _pump(self):
        chunks, done = [], []
        try:
            while True:
                item = self.q.get_nowait()
                (done if isinstance(item, tuple) else chunks).append(item)
        except queue.Empty:
            pass
        if chunks:
            self.log.configure(state="normal")
            self.log.insert("end", "".join(chunks))
            self.log.see("end")
            self.log.configure(state="disabled")
        for _, name, ok in done:
            self._done(name, ok)
        self.after(100, self._pump)

    # ── выбор файлов ──
    def _pick_video(self):
        p = filedialog.askopenfilename(title="Видео для AnyTube", filetypes=[("Видео и GIF", core.VIDEO_TYPES + " *.gif"), ("Все файлы", "*.*")])
        if p:
            self.v_path.set(p)
            self._on_file()

    def _on_file(self):
        stem = os.path.splitext(os.path.basename(self.v_path.get()))[0]
        if not self.v_title.get():
            self.v_title.set(stem)
        self.v_base.set(core.slug(stem))
        if self.v_path.get().lower().endswith(".gif") and not self.v_app.get():
            self.v_wall.set(True)
            self._money()

    def _pick_app(self):
        p = filedialog.askopenfilename(title="Файл приложения", filetypes=[("Приложения и архивы", core.APP_TYPES), ("Все файлы", "*.*")])
        if p:
            self.v_app_path.set(p)

    def _pick_txt(self, var):
        p = filedialog.askopenfilename(title="Описание", filetypes=[("Текст", "*.txt *.md"), ("Все файлы", "*.*")])
        var.set(p or "")

    # ── действия (в отдельном потоке, чтобы окно не зависало) ──
    def run(self, name, fn):
        if self.busy:
            return messagebox.showinfo("AnyTube", "Подождите, предыдущая операция ещё идёт.")
        if not core.CFG.get("token"):
            self.nb.select(self.tab_settings)
            return messagebox.showwarning("AnyTube", "Сначала вставьте токен GitHub во вкладке «Настройки».")
        self.busy = True
        self.pb.start(12)
        self.say(f"\n━━━ {name} ━━━\n")

        def work():
            ok = False
            try:
                fn()
                ok = True
            except core.Stop as e:
                self.say(f"\n❌ {e}\n")
            except Exception as e:
                self.say(f"\n❌ Ошибка: {e}\n{traceback.format_exc()}\n")
            finally:
                self.q.put(("__done__", name, ok))  # сигнал окну; tkinter трогаем только из главного потока
        threading.Thread(target=work, daemon=True).start()

    def _done(self, name, ok):
        self.busy = False
        self.pb.stop()
        self._acc()
        (messagebox.showinfo if ok else messagebox.showerror)("AnyTube", f"{name}: {'готово ✅' if ok else 'не получилось — подробности в журнале внизу'}")

    def _do_upload(self):
        modes = {"Git LFS — части до 1,9 ГБ": "lfs", "Сжать в один файл 95 МБ": "compress"}
        k = self.kind()
        sale = {}
        if self.v_paid.get() == "paid":
            if k == "video":
                sale = {"per_hour": self.v_hour.get(), "buy": self.v_buy.get()}
            elif k == "app":
                sale = {"buy": self.v_buy.get(), "sub": {p: v.get() for p, v in self.v_sub.items()}}
            else:
                sale = {"buy": self.v_buy.get()}
            if not core.normalize_sale(k, sale):
                return messagebox.showwarning("AnyTube", "Укажите хотя бы одну цену или выберите «бесплатно».")
        desc_text = self.t_desc.get("1.0", "end").strip()
        o = {"path": self.v_path.get(), "title": self.v_title.get(), "base": self.v_base.get(),
             "kind": k, "sale": sale, "app_path": self.v_app_path.get(), "trailer": self.v_trailer.get() or 60,
             "mode": modes.get(self.v_mode.get(), "plain"),
             "desc_file": self.v_desc_file.get() or None, "desc_text": None if self.v_desc_file.get() else (desc_text or None)}
        self.run("Загрузка", lambda: core.upload_item(o))

    def _do_desc(self):
        ref, file, text = self.v_d_ref.get(), self.v_d_file.get() or None, self.t_d.get("1.0", "end").strip()
        if not file and not text:
            return messagebox.showwarning("AnyTube", "Напишите описание или выберите .txt файл.")
        self.run("Описание", lambda: core.add_description(ref, file, None if file else text))

    def _do_comment(self):
        ref, text = self.v_c_ref.get(), self.t_c.get("1.0", "end").strip()
        if not text:
            return messagebox.showwarning("AnyTube", "Напишите комментарий.")
        self.run("Комментарий", lambda: core.post_comment(ref, text))

    def _do_dislike(self):
        ref, lvl = self.v_l_ref.get(), self.v_level.get()
        self.run("Дизлайк", lambda: core.post_dislike(ref, lvl))

    def _do_token(self):
        tok = self.v_token.get().strip().strip('"')
        if not tok:
            return messagebox.showwarning("AnyTube", "Вставьте токен.")
        core.CFG["token"] = tok
        core.save_config()

        def check():
            core.ensure_token()
            self.say(f"✅ Токен принят: {core.CFG['login']}" + (" · можно продавать (есть «repo»)\n" if core.CFG.get("scopes_repo")
                     else " · только бесплатные загрузки (для продажи нужна галочка «repo»)\n"))
        self.run("Проверка токена", check)

    def _save_site(self):
        core.CFG["site"] = self.v_site.get().strip().rstrip("/")
        core.CFG["platform"] = self.v_plat.get().strip() or "alekandrza14"
        core.save_config()
        self.say("✅ Настройки сайта сохранены\n")


def main():
    preset = next((a for a in sys.argv[1:] if os.path.isfile(a)), None)
    App(preset).mainloop()


if __name__ == "__main__":
    main()
